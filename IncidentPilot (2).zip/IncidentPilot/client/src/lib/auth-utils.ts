/**
 * Authentication utility for managing tokens across API requests
 * Supports both Clerk tokens and dev tokens for local development
 */

const TOKEN_STORAGE_KEY = "app_auth_token";
const TOKEN_EXPIRY_KEY = "app_auth_token_expiry";
const TOKEN_REFRESH_THRESHOLD = 5 * 60 * 1000; // Refresh 5 mins before expiry

interface TokenInfo {
  token: string;
  expiresAt?: number;
  type: "clerk" | "dev";
}

class AuthTokenManager {
  private currentToken: TokenInfo | null = null;

  /**
   * Get valid auth token - returns cached token or creates new one
   */
  async getAuthToken(): Promise<string> {
    // Try to use cached token if still valid
    if (this.currentToken) {
      if (this.isTokenValid(this.currentToken)) {
        return this.currentToken.token;
      }
    }

    // Try to get Clerk token if available
    const clerkToken = await this.getClerkToken();
    if (clerkToken) {
      this.currentToken = {
        token: clerkToken,
        type: "clerk",
        expiresAt: Date.now() + 60 * 60 * 1000, // Clerk tokens typically last 1 hour
      };
      this.saveTokenToStorage(this.currentToken);
      return clerkToken;
    }

    // Fall back to dev token (for development/testing)
    const devToken = this.getOrCreateDevToken();
    this.currentToken = {
      token: devToken,
      type: "dev",
    };
    return devToken;
  }

  /**
   * Try to get token from Clerk (if integrated)
   */
  private async getClerkToken(): Promise<string | null> {
    try {
      // Check if Clerk is available in window
      const clerkWindow = (window as any).Clerk;
      if (!clerkWindow || !clerkWindow.session) {
        return null;
      }

      // Get session token from Clerk
      const token = await clerkWindow.session.getToken();
      return token || null;
    } catch (error) {
      console.debug("Clerk token unavailable, using fallback token", error);
      return null;
    }
  }

  /**
   * Get or create development token
   */
  private getOrCreateDevToken(): string {
    const stored = sessionStorage.getItem(TOKEN_STORAGE_KEY);
    if (stored) {
      return stored;
    }

    // Create new dev token with timestamp
    const newToken = `dev_token_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    sessionStorage.setItem(TOKEN_STORAGE_KEY, newToken);
    return newToken;
  }

  /**
   * Check if token is still valid
   */
  private isTokenValid(tokenInfo: TokenInfo): boolean {
    if (!tokenInfo.expiresAt) {
      // Dev tokens don't expire
      return true;
    }

    // Check if token will expire soon
    const timeUntilExpiry = tokenInfo.expiresAt - Date.now();
    return timeUntilExpiry > TOKEN_REFRESH_THRESHOLD;
  }

  /**
   * Save token to storage for persistence
   */
  private saveTokenToStorage(tokenInfo: TokenInfo): void {
    try {
      sessionStorage.setItem(TOKEN_STORAGE_KEY, tokenInfo.token);
      if (tokenInfo.expiresAt) {
        sessionStorage.setItem(TOKEN_EXPIRY_KEY, tokenInfo.expiresAt.toString());
      }
    } catch (error) {
      console.warn("Failed to save token to storage", error);
    }
  }

  /**
   * Clear stored tokens
   */
  clearTokens(): void {
    this.currentToken = null;
    sessionStorage.removeItem(TOKEN_STORAGE_KEY);
    sessionStorage.removeItem(TOKEN_EXPIRY_KEY);
  }

  /**
   * Get current token info (for debugging)
   */
  getCurrentTokenInfo(): TokenInfo | null {
    return this.currentToken;
  }
}

// Singleton instance
export const authTokenManager = new AuthTokenManager();

/**
 * Add auth header to request
 */
export async function addAuthHeaders(
  headers: HeadersInit = {}
): Promise<HeadersInit> {
  const token = await authTokenManager.getAuthToken();
  return {
    ...headers,
    "Authorization": `Bearer ${token}`,
  };
}

/**
 * Create authenticated fetch options
 */
export async function createAuthFetchOptions(
  options: RequestInit = {}
): Promise<RequestInit> {
  const headers = await addAuthHeaders(options.headers);
  return {
    ...options,
    headers,
    credentials: "include", // Include cookies for session support
  };
}
