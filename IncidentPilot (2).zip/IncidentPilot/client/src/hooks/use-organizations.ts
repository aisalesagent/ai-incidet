import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Organization } from "@shared/schema";

export function useOrganizations() {
  return useQuery({
    queryKey: ["/api/organizations"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/organizations");
      return res.json() as Promise<Organization[]>;
    },
  });
}

export function useOrganization(id?: string) {
  return useQuery({
    queryKey: ["/api/organizations", id],
    queryFn: async () => {
      if (!id) return null;
      const res = await apiRequest("GET", `/api/organizations/${id}`);
      return res.json() as Promise<Organization>;
    },
    enabled: !!id,
  });
}

export function useCreateOrganization() {
  return useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/organizations", data);
      return res.json() as Promise<Organization>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations"] });
    },
  });
}

export function useOrganizationMembers(organizationId?: string) {
  return useQuery({
    queryKey: ["/api/organizations", organizationId, "members"],
    queryFn: async () => {
      if (!organizationId) return [];
      const res = await apiRequest("GET", `/api/organizations/${organizationId}/members`);
      return res.json();
    },
    enabled: !!organizationId,
  });
}
