import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Incident } from "@shared/schema";

export function useIncidents(organizationId?: string, filters?: { status?: string; severity?: string }) {
  return useQuery({
    queryKey: ["/api/incidents", organizationId, filters],
    queryFn: async () => {
      if (!organizationId) return [];
      const params = new URLSearchParams({ organizationId, ...filters });
      const res = await apiRequest("GET", `/api/incidents?${params}`);
      return res.json() as Promise<Incident[]>;
    },
    enabled: !!organizationId,
  });
}

export function useIncident(id?: string) {
  return useQuery({
    queryKey: ["/api/incidents", id],
    queryFn: async () => {
      if (!id) return null;
      const res = await apiRequest("GET", `/api/incidents/${id}`);
      return res.json() as Promise<Incident>;
    },
    enabled: !!id,
  });
}

export function useCreateIncident(organizationId?: string) {
  return useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/incidents", { ...data, organizationId });
      return res.json() as Promise<Incident>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/incidents"] });
    },
  });
}

export function useUpdateIncident(id?: string) {
  return useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", `/api/incidents/${id}`, data);
      return res.json() as Promise<Incident>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/incidents"] });
    },
  });
}

export function useAnalyzeIncident(id?: string) {
  return useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/incidents/${id}/analyze`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/incidents", id] });
    },
  });
}

export function useIncidentActivities(incidentId?: string) {
  return useQuery({
    queryKey: ["/api/incidents", incidentId, "activities"],
    queryFn: async () => {
      if (!incidentId) return [];
      const res = await apiRequest("GET", `/api/incidents/${incidentId}/activities`);
      return res.json() as Promise<any[]>;
    },
    enabled: !!incidentId,
  });
}
