import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

// Mock auth hook - in production, integrate with Clerk
export function useAuth() {
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      try {
        const res = await apiRequest("GET", "/api/auth/me");
        return res.json();
      } catch {
        // Return mock user for demo
        return {
          id: "user-demo",
          name: "Demo User",
          email: "demo@example.com",
          avatar: "",
        };
      }
    },
  });

  return { user, isLoading };
}

export function useCurrentOrganization() {
  // Get from localStorage or query param
  const orgId = new URLSearchParams(window.location.search).get("org") ||
    localStorage.getItem("currentOrgId") ||
    "org-default";

  return { organizationId: orgId };
}
