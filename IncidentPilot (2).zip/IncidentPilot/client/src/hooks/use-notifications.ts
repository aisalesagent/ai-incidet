import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Notification } from "@shared/schema";

export function useNotifications(limit?: number) {
  return useQuery({
    queryKey: ["/api/notifications", limit],
    queryFn: async () => {
      const params = limit ? `?limit=${limit}` : "";
      const res = await apiRequest("GET", `/api/notifications${params}`);
      return res.json() as Promise<Notification[]>;
    },
    refetchInterval: 5000, // Poll every 5 seconds
  });
}

export function useUnreadNotificationCount() {
  return useQuery({
    queryKey: ["/api/notifications/unread/count"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/notifications/unread/count");
      return res.json() as Promise<{ count: number }>;
    },
    refetchInterval: 5000,
  });
}

export function useMarkNotificationRead(id?: string) {
  return useMutation({
    mutationFn: async () => {
      await apiRequest("PATCH", `/api/notifications/${id}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread/count"] });
    },
  });
}
