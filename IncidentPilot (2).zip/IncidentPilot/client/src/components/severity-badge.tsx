import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export type IncidentSeverity = "critical" | "high" | "medium" | "low";

const severityConfig: Record<
  IncidentSeverity,
  { label: string; className: string }
> = {
  critical: {
    label: "Critical",
    className: "bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20 font-semibold",
  },
  high: {
    label: "High",
    className: "bg-orange-500/10 text-orange-700 dark:text-orange-400 border-orange-500/20 font-semibold",
  },
  medium: {
    label: "Medium",
    className: "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20",
  },
  low: {
    label: "Low",
    className: "bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20",
  },
};

export function SeverityBadge({ severity }: { severity: IncidentSeverity }) {
  const config = severityConfig[severity];

  return (
    <Badge
      variant="outline"
      className={cn("uppercase text-xs tracking-wide", config.className)}
      data-testid={`badge-severity-${severity}`}
    >
      {config.label}
    </Badge>
  );
}
