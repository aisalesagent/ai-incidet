import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Sparkles, RefreshCw, ThumbsUp, ThumbsDown } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface AIAnalysisCardProps {
  title: string;
  content?: string;
  isLoading?: boolean;
  onRegenerate?: () => void;
  confidence?: number;
}

export function AIAnalysisCard({
  title,
  content,
  isLoading = false,
  onRegenerate,
  confidence,
}: AIAnalysisCardProps) {
  if (isLoading) {
    return (
      <Card data-testid="card-ai-loading">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <CardTitle className="text-lg">{title}</CardTitle>
            </div>
            <Badge variant="secondary" className="gap-1">
              <Sparkles className="h-3 w-3" />
              AI Generated
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
        </CardContent>
      </Card>
    );
  }

  if (!content) {
    return (
      <Card data-testid="card-ai-empty">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-muted-foreground" />
            <CardTitle className="text-lg text-muted-foreground">{title}</CardTitle>
          </div>
          <CardDescription>
            AI analysis will appear here once generated
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="border-primary/20" data-testid="card-ai-analysis">
      <CardHeader>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <CardTitle className="text-lg">{title}</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            {confidence !== undefined && (
              <Badge variant="secondary" className="text-xs">
                {Math.round(confidence * 100)}% confidence
              </Badge>
            )}
            <Badge variant="secondary" className="gap-1">
              <Sparkles className="h-3 w-3" />
              AI Generated
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="prose prose-sm dark:prose-invert max-w-none">
          <div className="whitespace-pre-wrap text-sm leading-relaxed" data-testid="text-ai-content">
            {content}
          </div>
        </div>
        <div className="flex items-center justify-between pt-2 border-t">
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="h-8 gap-1"
              data-testid="button-ai-helpful"
            >
              <ThumbsUp className="h-3 w-3" />
              Helpful
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 gap-1"
              data-testid="button-ai-not-helpful"
            >
              <ThumbsDown className="h-3 w-3" />
              Not Helpful
            </Button>
          </div>
          {onRegenerate && (
            <Button
              variant="outline"
              size="sm"
              onClick={onRegenerate}
              className="gap-1"
              data-testid="button-regenerate"
            >
              <RefreshCw className="h-3 w-3" />
              Regenerate
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
