import { Card } from "@/components/ui/card";
import { StatusBadge, type IncidentStatus } from "@/components/status-badge";
import { SeverityBadge, type IncidentSeverity } from "@/components/severity-badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";

interface IncidentCardProps {
  id: string;
  title: string;
  status: IncidentStatus;
  severity: IncidentSeverity;
  assignedTo?: {
    name: string;
    avatar?: string;
  };
  tags?: string[];
  createdAt: Date;
}

export function IncidentCard({
  id,
  title,
  status,
  severity,
  assignedTo,
  tags = [],
  createdAt,
}: IncidentCardProps) {
  const assigneeInitials = assignedTo?.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();

  return (
    <Link href={`/incidents/${id}`}>
      <Card
        className="p-4 hover-elevate cursor-pointer transition-all"
        data-testid={`card-incident-${id}`}
      >
        <div className="flex items-start gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-start gap-2 mb-2">
              <StatusBadge status={status} />
              <SeverityBadge severity={severity} />
            </div>
            <h3 className="text-base font-medium mb-2 truncate" data-testid="text-incident-title">
              {title}
            </h3>
            <div className="flex items-center gap-3 flex-wrap">
              {assignedTo ? (
                <div className="flex items-center gap-2">
                  <Avatar className="h-6 w-6">
                    <AvatarImage src={assignedTo.avatar} />
                    <AvatarFallback className="text-xs">
                      {assigneeInitials}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm text-muted-foreground">
                    {assignedTo.name}
                  </span>
                </div>
              ) : (
                <span className="text-sm text-muted-foreground">Unassigned</span>
              )}
              <span className="text-sm text-muted-foreground">
                {formatDistanceToNow(createdAt, { addSuffix: true })}
              </span>
            </div>
            {tags.length > 0 && (
              <div className="flex gap-1 mt-2 flex-wrap">
                {tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>
      </Card>
    </Link>
  );
}
