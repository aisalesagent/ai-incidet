import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { IncidentCard } from "@/components/incident-card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Search, Filter, Loader2, AlertCircle } from "lucide-react";
import { Link } from "wouter";
import { useIncidents } from "@/hooks/use-incidents";
import { useCurrentOrganization } from "@/hooks/use-auth";

// Mock data for fallback
const mockIncidents = [
  {
    id: "inc-001",
    title: "Production database connection timeout",
    status: "investigating" as const,
    severity: "critical" as const,
    assignedTo: { name: "Sarah Chen", avatar: "" },
    tags: ["database", "production"],
    createdAt: new Date(Date.now() - 30 * 60 * 1000),
  },
  {
    id: "inc-002",
    title: "API rate limiting errors in payment service",
    status: "open" as const,
    severity: "high" as const,
    assignedTo: { name: "Mike Johnson", avatar: "" },
    tags: ["api", "payment"],
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
  },
  {
    id: "inc-003",
    title: "Slow page load times on dashboard",
    status: "resolved" as const,
    severity: "medium" as const,
    assignedTo: { name: "Alex Kim", avatar: "" },
    tags: ["performance", "frontend"],
    createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
  },
  {
    id: "inc-004",
    title: "Memory leak in background job processor",
    status: "open" as const,
    severity: "high" as const,
    tags: ["backend", "jobs"],
    createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
  },
  {
    id: "inc-005",
    title: "Image upload failing on mobile devices",
    status: "investigating" as const,
    severity: "medium" as const,
    assignedTo: { name: "Jordan Lee", avatar: "" },
    tags: ["mobile", "upload"],
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
  },
  {
    id: "inc-006",
    title: "Email notifications delayed by 2+ hours",
    status: "resolved" as const,
    severity: "low" as const,
    assignedTo: { name: "Chris Taylor", avatar: "" },
    tags: ["notifications", "email"],
    createdAt: new Date(Date.now() - 48 * 60 * 60 * 1000),
  },
];

export default function Incidents() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [severityFilter, setSeverityFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  
  const { organizationId } = useCurrentOrganization();
  const { data: incidents = mockIncidents, isLoading, error } = useIncidents(
    organizationId,
    statusFilter !== "all" || severityFilter !== "all"
      ? {
          status: statusFilter !== "all" ? statusFilter : undefined,
          severity: severityFilter !== "all" ? severityFilter : undefined,
        }
      : undefined
  );

  const filteredIncidents = (incidents || mockIncidents).filter((incident: any) => {
    if (searchQuery && !incident.title.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight" data-testid="heading-incidents">
            Incidents
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage and track all incidents across your organization
          </p>
        </div>
        <Link href="/incidents/new">
          <Button className="gap-2" data-testid="button-create-incident">
            <Plus className="h-4 w-4" />
            Create Incident
          </Button>
        </Link>
      </div>

      <div className="flex items-center gap-4 flex-wrap p-4 rounded-lg border bg-card">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search incidents..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            data-testid="input-search"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px]" data-testid="select-status-filter">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="investigating">Investigating</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
          </SelectContent>
        </Select>
        <Select value={severityFilter} onValueChange={setSeverityFilter}>
          <SelectTrigger className="w-[150px]" data-testid="select-severity-filter">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Severity</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="low">Low</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center py-12 border rounded-lg bg-muted/20">
            <Loader2 className="h-12 w-12 mx-auto text-muted-foreground mb-4 animate-spin" />
            <h3 className="text-lg font-medium mb-1">Loading incidents...</h3>
          </div>
        ) : error ? (
          <div className="text-center py-12 border rounded-lg bg-muted/20">
            <AlertCircle className="h-12 w-12 mx-auto text-destructive mb-4" />
            <h3 className="text-lg font-medium mb-1">Error loading incidents</h3>
            <p className="text-sm text-muted-foreground">{error.message}</p>
          </div>
        ) : filteredIncidents.length === 0 ? (
          <div className="text-center py-12 border rounded-lg bg-muted/20" data-testid="empty-state">
            <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-1">No incidents found</h3>
            <p className="text-sm text-muted-foreground mb-4">
              {searchQuery || statusFilter !== "all" || severityFilter !== "all"
                ? "Try adjusting your filters"
                : "Get started by creating your first incident"}
            </p>
            {!searchQuery && statusFilter === "all" && severityFilter === "all" && (
              <Link href="/incidents/new">
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  Create Incident
                </Button>
              </Link>
            )}
          </div>
        ) : (
          <>
            <div className="text-sm text-muted-foreground" data-testid="text-result-count">
              Showing {filteredIncidents.length} incident{filteredIncidents.length !== 1 ? "s" : ""}
            </div>
            {filteredIncidents.map((incident: any) => (
              <IncidentCard key={incident.id} {...incident} />
            ))}
          </>
        )}
      </div>
    </div>
  );
}
