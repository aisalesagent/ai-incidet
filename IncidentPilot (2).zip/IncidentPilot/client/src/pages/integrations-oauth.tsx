/**
 * OAuth Integration Handler
 * Manages OAuth flows and callbacks for third-party integrations
 */

import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, AlertCircle, Loader2 } from "lucide-react";

export function OAuthIntegrationHandler() {
  const { toast } = useToast();
  const [status, setStatus] = useState<"success" | "error" | "loading" | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const statusParam = params.get("status");
    const provider = params.get("provider");

    if (statusParam === "success") {
      setStatus("success");
      toast({
        title: "Integration Connected",
        description: `${provider?.charAt(0).toUpperCase()}${provider?.slice(1)} has been successfully connected.`,
      });
      // Clear URL params
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (statusParam === "error") {
      setStatus("error");
      toast({
        title: "Connection Failed",
        description: `Failed to connect ${provider}. Please try again.`,
        variant: "destructive",
      });
      // Clear URL params
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [toast]);

  if (status === "loading") {
    return (
      <div className="flex items-center justify-center p-6">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (status === "success") {
    return (
      <Alert className="border-green-200 bg-green-50 dark:border-green-900 dark:bg-green-950">
        <CheckCircle className="h-4 w-4 text-green-600" />
        <AlertDescription className="text-green-800 dark:text-green-200" data-testid="alert-success-oauth">
          Integration connected successfully! You can now use this service.
        </AlertDescription>
      </Alert>
    );
  }

  if (status === "error") {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription data-testid="alert-error-oauth">
          Failed to connect integration. Please check your credentials and try again.
        </AlertDescription>
      </Alert>
    );
  }

  return null;
}
