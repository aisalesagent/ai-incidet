import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatusBadge } from "@/components/status-badge";
import { SeverityBadge } from "@/components/severity-badge";
import { AIAnalysisCard } from "@/components/ai-analysis-card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  ArrowLeft,
  Edit,
  MoreVertical,
  Github,
  ExternalLink,
  Clock,
  User,
  Sparkles,
  Loader2,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatDistanceToNow, format } from "date-fns";
import { useIncident, useIncidentActivities, useAnalyzeIncident } from "@/hooks/use-incidents";

// Mock data - will be replaced with real data
const mockIncident = {
  id: "inc-001",
  title: "Production database connection timeout",
  description: "Users are experiencing intermittent connection timeouts when accessing the main database. Error logs show 'connection pool exhausted' messages. This started approximately 30 minutes ago and is affecting approximately 25% of user requests.",
  status: "investigating" as const,
  severity: "critical" as const,
  createdBy: { name: "Sarah Chen", avatar: "", email: "sarah@example.com" },
  assignedTo: { name: "Mike Johnson", avatar: "", email: "mike@example.com" },
  tags: ["database", "production", "timeout"],
  metadata: {
    environment: "production",
    service: "auth-service",
    region: "us-east-1",
    affectedUsers: 1250,
  },
  aiAnalysis: {
    severityPrediction: {
      severity: "critical",
      confidence: 0.92,
    },
    rca: "The root cause appears to be a gradual memory leak in the connection pool management system. Analysis of system metrics shows a steady increase in allocated but unused connections over the past 6 hours, eventually leading to pool exhaustion.\n\nKey findings:\n- Connection pool size remained at maximum (500) for 45 minutes before failure\n- Memory usage increased by 40% over 6-hour period\n- No corresponding increase in actual query volume\n- Connection cleanup logic appears to have stopped executing\n\nLikely trigger: Recent deployment (v2.3.4) introduced a change to connection timeout handling that prevents proper connection cleanup.",
    impactAssessment: "HIGH IMPACT - This incident is affecting core authentication services in production. Approximately 1,250 active users are experiencing degraded service, with 25% of requests failing. Revenue impact estimated at $5,000/hour based on typical conversion rates. Customer satisfaction scores have dropped 15% in the last 30 minutes.",
    actionPlan: {
      steps: [
        "Immediately increase connection pool size to 750 as temporary mitigation",
        "Roll back deployment v2.3.4 to previous stable version v2.3.3",
        "Monitor connection pool metrics for 15 minutes to confirm stabilization",
        "Review code changes in v2.3.4 related to connection timeout handling",
        "Implement additional monitoring alerts for connection pool exhaustion",
        "Schedule postmortem meeting within 24 hours",
      ],
      estimatedTime: "45-60 minutes to full resolution",
    },
    postmortem: {
      summary: "Production database connection pool exhaustion caused by memory leak in v2.3.4 deployment. Affected 1,250 users for 90 minutes before resolution.",
      timeline: [
        {
          time: "14:00",
          event: "Deployment v2.3.4 completed",
          type: "deployment",
        },
        {
          time: "14:30",
          event: "First alerts for increased connection pool usage",
          type: "warning",
        },
        {
          time: "15:45",
          event: "Connection pool exhaustion, service degradation begins",
          type: "incident",
        },
        {
          time: "15:50",
          event: "Incident created, on-call engineer paged",
          type: "response",
        },
        {
          time: "16:15",
          event: "Rollback initiated to v2.3.3",
          type: "mitigation",
        },
        {
          time: "16:30",
          event: "Service fully restored, incident resolved",
          type: "resolution",
        },
      ],
      lessonsLearned: [
        "Need more comprehensive integration testing for database connection handling",
        "Implement gradual rollout strategy (canary deployments) for backend services",
        "Add automated rollback triggers based on connection pool metrics",
        "Improve alerting thresholds to catch gradual resource exhaustion earlier",
        "Require peer review for all connection management code changes",
      ],
    },
  },
  githubIssueUrl: "https://github.com/company/repo/issues/456",
  jiraTicketKey: "PROD-123",
  createdAt: new Date(Date.now() - 90 * 60 * 1000),
  updatedAt: new Date(Date.now() - 5 * 60 * 1000),
  activities: [
    {
      id: "1",
      type: "created",
      user: { name: "Sarah Chen", avatar: "" },
      content: "Incident created",
      timestamp: new Date(Date.now() - 90 * 60 * 1000),
    },
    {
      id: "2",
      type: "assigned",
      user: { name: "Sarah Chen", avatar: "" },
      content: "Assigned to Mike Johnson",
      timestamp: new Date(Date.now() - 85 * 60 * 1000),
    },
    {
      id: "3",
      type: "status_change",
      user: { name: "Mike Johnson", avatar: "" },
      content: "Status changed to Investigating",
      timestamp: new Date(Date.now() - 80 * 60 * 1000),
    },
    {
      id: "4",
      type: "ai_analysis",
      content: "AI analysis completed",
      timestamp: new Date(Date.now() - 75 * 60 * 1000),
    },
    {
      id: "5",
      type: "comment",
      user: { name: "Mike Johnson", avatar: "" },
      content: "Initiated rollback to v2.3.3 as suggested by AI analysis",
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
    },
  ],
};

export default function IncidentDetail() {
  const [, params] = useRoute("/incidents/:id");
  const incidentId = params?.id;
  
  const { data: incident = mockIncident, isLoading } = useIncident(incidentId);
  const { data: activities = mockIncident.activities } = useIncidentActivities(incidentId);
  const analyzeIncident = useAnalyzeIncident(incidentId);

  const displayIncident = incident || mockIncident;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/incidents">
          <Button variant="ghost" size="icon" data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex-1">
          {isLoading ? (
            <div className="flex items-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              <p className="text-muted-foreground">Loading incident...</p>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm text-muted-foreground font-mono">
                  {displayIncident.id}
                </span>
                <StatusBadge status={displayIncident.status} />
                <SeverityBadge severity={displayIncident.severity} />
              </div>
              <h1 className="text-3xl font-semibold tracking-tight" data-testid="heading-incident-title">
                {displayIncident.title}
              </h1>
            </>
          )}
        </div>
        {!isLoading && (
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              className="gap-2" 
              data-testid="button-edit"
              onClick={() => analyzeIncident.mutate()}
              disabled={analyzeIncident.isPending}
            >
              {analyzeIncident.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  Analyze
                </>
              )}
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon" data-testid="button-more">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem data-testid="menu-duplicate">Duplicate</DropdownMenuItem>
                <DropdownMenuItem data-testid="menu-archive">Archive</DropdownMenuItem>
                <DropdownMenuItem className="text-destructive" data-testid="menu-delete">
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          {isLoading ? (
            <Card>
              <CardContent className="flex items-center justify-center py-12">
                <div className="text-center">
                  <Loader2 className="h-8 w-8 mx-auto text-muted-foreground animate-spin mb-4" />
                  <p className="text-muted-foreground">Loading incident details...</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm leading-relaxed whitespace-pre-wrap" data-testid="text-description">
                  {displayIncident.description}
                </p>
              </CardContent>
            </Card>
          )}

          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
              <TabsTrigger value="rca" data-testid="tab-rca">RCA</TabsTrigger>
              <TabsTrigger value="action-plan" data-testid="tab-action-plan">Action Plan</TabsTrigger>
              <TabsTrigger value="postmortem" data-testid="tab-postmortem">Postmortem</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4 mt-4">
              {displayIncident.aiAnalysis ? (
                <>
                  <AIAnalysisCard
                    title="Impact Assessment"
                    content={displayIncident.aiAnalysis.impactAssessment}
                    confidence={0.88}
                  />
                  <AIAnalysisCard
                    title="Severity Prediction"
                    content={`Predicted Severity: ${displayIncident.aiAnalysis.severityPrediction.severity.toUpperCase()}\n\nThis incident has been automatically classified as ${displayIncident.aiAnalysis.severityPrediction.severity} severity based on:\n- Affected user count (${displayIncident.metadata?.affectedUsers || 'unknown'} users)\n- Service criticality (${displayIncident.metadata?.service || 'unknown'} service)\n- Environment: ${displayIncident.metadata?.environment || 'unknown'}`}
                    confidence={displayIncident.aiAnalysis.severityPrediction.confidence}
                  />
                </>
              ) : (
                <div className="text-center py-8 border rounded-lg bg-muted/20">
                  <Sparkles className="h-8 w-8 mx-auto text-muted-foreground mb-4" />
                  <p className="text-sm text-muted-foreground">No AI analysis available yet. Click Analyze to generate insights.</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="rca" className="mt-4">
              <AIAnalysisCard
                title="Root Cause Analysis"
                content={mockIncident.aiAnalysis.rca}
                confidence={0.85}
                onRegenerate={() => console.log("Regenerate RCA")}
              />
            </TabsContent>

            <TabsContent value="action-plan" className="mt-4">
              <Card className="border-primary/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-primary" />
                    <CardTitle className="text-lg">Recommended Action Plan</CardTitle>
                    <Badge variant="secondary" className="ml-auto gap-1">
                      <Sparkles className="h-3 w-3" />
                      AI Generated
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    {mockIncident.aiAnalysis.actionPlan.steps.map((step, index) => (
                      <div
                        key={index}
                        className="flex gap-3 p-3 rounded-md bg-muted/50"
                        data-testid={`action-step-${index}`}
                      >
                        <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-medium">
                          {index + 1}
                        </div>
                        <p className="text-sm leading-relaxed pt-0.5">{step}</p>
                      </div>
                    ))}
                  </div>
                  <Separator />
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-muted-foreground">Estimated time:</span>
                    <span className="font-medium">{mockIncident.aiAnalysis.actionPlan.estimatedTime}</span>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="postmortem" className="space-y-4 mt-4">
              <Card className="border-primary/20">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-primary" />
                    <CardTitle className="text-lg">Postmortem Report</CardTitle>
                    <Badge variant="secondary" className="ml-auto gap-1">
                      <Sparkles className="h-3 w-3" />
                      AI Generated
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h4 className="text-sm font-semibold mb-2">Summary</h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {mockIncident.aiAnalysis.postmortem.summary}
                    </p>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold mb-3">Timeline</h4>
                    <div className="space-y-3">
                      {mockIncident.aiAnalysis.postmortem.timeline.map((event, index) => (
                        <div key={index} className="flex gap-3">
                          <div className="flex flex-col items-center">
                            <div className={`h-2 w-2 rounded-full ${
                              event.type === "incident" ? "bg-destructive" :
                              event.type === "resolution" ? "bg-green-500" :
                              event.type === "mitigation" ? "bg-blue-500" :
                              "bg-muted-foreground"
                            }`}></div>
                            {index < mockIncident.aiAnalysis.postmortem.timeline.length - 1 && (
                              <div className="w-px h-full bg-border mt-1"></div>
                            )}
                          </div>
                          <div className="pb-4">
                            <div className="text-sm font-mono text-muted-foreground mb-1">
                              {event.time}
                            </div>
                            <p className="text-sm">{event.event}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold mb-3">Lessons Learned</h4>
                    <ul className="space-y-2">
                      {mockIncident.aiAnalysis.postmortem.lessonsLearned.map((lesson, index) => (
                        <li key={index} className="flex gap-2 text-sm text-muted-foreground">
                          <span className="text-primary">•</span>
                          <span>{lesson}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div>
                <div className="text-muted-foreground mb-1">Created By</div>
                <div className="flex items-center gap-2">
                  <Avatar className="h-6 w-6">
                    <AvatarImage src={mockIncident.createdBy.avatar} />
                    <AvatarFallback className="text-xs">
                      {mockIncident.createdBy.name.split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <span className="font-medium">{mockIncident.createdBy.name}</span>
                </div>
              </div>

              <Separator />

              <div>
                <div className="text-muted-foreground mb-1">Assigned To</div>
                <div className="flex items-center gap-2">
                  <Avatar className="h-6 w-6">
                    <AvatarImage src={mockIncident.assignedTo.avatar} />
                    <AvatarFallback className="text-xs">
                      {mockIncident.assignedTo.name.split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <span className="font-medium">{mockIncident.assignedTo.name}</span>
                </div>
              </div>

              <Separator />

              <div>
                <div className="text-muted-foreground mb-1">Created</div>
                <div className="font-medium">
                  {formatDistanceToNow(mockIncident.createdAt, { addSuffix: true })}
                </div>
                <div className="text-xs text-muted-foreground">
                  {format(mockIncident.createdAt, "PPpp")}
                </div>
              </div>

              <Separator />

              <div>
                <div className="text-muted-foreground mb-2">Tags</div>
                <div className="flex flex-wrap gap-1">
                  {mockIncident.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>

              <Separator />

              <div>
                <div className="text-muted-foreground mb-1">Environment</div>
                <div className="font-medium">{mockIncident.metadata.environment}</div>
              </div>

              <div>
                <div className="text-muted-foreground mb-1">Service</div>
                <div className="font-medium">{mockIncident.metadata.service}</div>
              </div>

              <div>
                <div className="text-muted-foreground mb-1">Region</div>
                <div className="font-medium">{mockIncident.metadata.region}</div>
              </div>

              <div>
                <div className="text-muted-foreground mb-1">Affected Users</div>
                <div className="font-medium">{mockIncident.metadata.affectedUsers.toLocaleString()}</div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Integrations</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {mockIncident.githubIssueUrl && (
                <a
                  href={mockIncident.githubIssueUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-2 rounded-md hover-elevate border"
                  data-testid="link-github"
                >
                  <Github className="h-4 w-4" />
                  <span className="text-sm font-medium flex-1">GitHub Issue</span>
                  <ExternalLink className="h-3 w-3 text-muted-foreground" />
                </a>
              )}
              {mockIncident.jiraTicketKey && (
                <a
                  href={`https://jira.example.com/browse/${mockIncident.jiraTicketKey}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-2 rounded-md hover-elevate border"
                  data-testid="link-jira"
                >
                  <div className="h-4 w-4 rounded bg-blue-500 text-white text-xs font-bold flex items-center justify-center">
                    J
                  </div>
                  <span className="text-sm font-medium flex-1">{mockIncident.jiraTicketKey}</span>
                  <ExternalLink className="h-3 w-3 text-muted-foreground" />
                </a>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockIncident.activities.map((activity) => (
                  <div key={activity.id} className="flex gap-3 text-sm">
                    <div className="flex flex-col items-center">
                      <div className="h-2 w-2 rounded-full bg-primary mt-1.5"></div>
                      <div className="w-px flex-1 bg-border mt-1"></div>
                    </div>
                    <div className="flex-1 pb-2">
                      {activity.user && (
                        <div className="font-medium mb-0.5">{activity.user.name}</div>
                      )}
                      <div className="text-muted-foreground">{activity.content}</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {formatDistanceToNow(activity.timestamp, { addSuffix: true })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
