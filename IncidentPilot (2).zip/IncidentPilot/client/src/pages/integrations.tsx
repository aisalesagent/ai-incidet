import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Github, Zap, Slack, CreditCard } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { OAuthIntegrationHandler } from "./integrations-oauth";
import { authTokenManager } from "@/lib/auth-utils";

const INTEGRATION_TYPES = [
  {
    id: "github",
    name: "GitHub",
    description: "Link GitHub repositories and automatically create issues",
    icon: Github,
    oauthEnabled: true,
  },
  {
    id: "jira",
    name: "Jira",
    description: "Sync incidents with Jira tickets for tracking",
    icon: Zap,
    oauthEnabled: true,
  },
  {
    id: "slack",
    name: "Slack",
    description: "Send incident notifications to Slack channels",
    icon: Slack,
    oauthEnabled: true,
  },
  {
    id: "stripe",
    name: "Stripe",
    description: "Manage billing and payments",
    icon: CreditCard,
    oauthEnabled: false,
  },
];

export default function Integrations() {
  const { toast } = useToast();
  const [connecting, setConnecting] = useState<string | null>(null);
  
  const { data: integrations = [], isLoading } = useQuery({
    queryKey: ["/api/integrations", "default"],
    queryFn: async () => {
      const response = await fetch("/api/integrations?organizationId=default");
      if (!response.ok) return [];
      return response.json();
    },
  });

  const handleOAuthStart = async (type: string) => {
    try {
      setConnecting(type);
      const orgId = "default"; // Default organization
      const token = await authTokenManager.getAuthToken();
      
      const response = await fetch(
        `/api/oauth/authorize?provider=${type}&organizationId=${orgId}`,
        {
          headers: {
            "Authorization": `Bearer ${token}`,
          },
        }
      );

      if (!response.ok) {
        const error = await response.json() as { error: string };
        throw new Error(error.error || "Failed to get authorization URL");
      }

      const data = await response.json() as { authUrl: string };
      window.location.href = data.authUrl;
    } catch (error) {
      console.error("OAuth error:", error);
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : "Failed to initiate OAuth flow",
        variant: "destructive",
      });
      setConnecting(null);
    }
  };

  const isConfigured = (type: string) => {
    return integrations?.some((i: any) => i.type === type);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-integrations">
          Integrations
        </h1>
        <p className="text-muted-foreground mt-2">
          Connect third-party tools to automate incident management
        </p>
      </div>

      <OAuthIntegrationHandler />

      <div className="grid gap-4">
        {INTEGRATION_TYPES.map((integration) => {
          const Icon = integration.icon;
          const configured = isConfigured(integration.id);
          const isConnecting = connecting === integration.id;

          return (
            <Card key={integration.id} className="hover-elevate">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className="rounded-lg bg-primary/10 p-2">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle>{integration.name}</CardTitle>
                      <CardDescription>{integration.description}</CardDescription>
                    </div>
                  </div>
                  {configured && (
                    <Badge className="ml-auto" data-testid={`badge-status-${integration.id}`}>
                      Connected
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2">
                  {integration.oauthEnabled ? (
                    <>
                      <Button
                        variant="outline"
                        disabled={isConnecting}
                        onClick={() => handleOAuthStart(integration.id)}
                        data-testid={`button-${configured ? "reconnect" : "connect"}-${integration.id}`}
                      >
                        {isConnecting ? "Connecting..." : configured ? "Reconnect" : "Connect"}
                      </Button>
                      {configured && (
                        <Button 
                          variant="ghost" 
                          onClick={async () => {
                            try {
                              const response = await fetch(
                                `/api/integrations/${integration.id}`,
                                { method: "DELETE" }
                              );
                              if (response.ok) {
                                toast({ title: "Integration disconnected" });
                                // Refetch integrations
                                window.location.reload();
                              }
                            } catch (err) {
                              toast({ title: "Error disconnecting", variant: "destructive" });
                            }
                          }}
                          data-testid={`button-disconnect-${integration.id}`}
                        >
                          Disconnect
                        </Button>
                      )}
                    </>
                  ) : (
                    <Button variant="outline" disabled>
                      Coming Soon
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Webhook URLs</CardTitle>
          <CardDescription>Use these URLs for incoming integrations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium mb-2">GitHub Webhook</p>
              <code className="text-xs bg-muted p-2 rounded-md block break-all" data-testid="code-webhook-github">
                https://api.incident.ai/webhooks/github
              </code>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
