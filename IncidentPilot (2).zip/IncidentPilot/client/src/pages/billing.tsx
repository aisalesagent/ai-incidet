import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";

const PLANS = [
  {
    name: "Free",
    price: "$0",
    description: "Perfect for getting started",
    current: true,
    features: [
      "Up to 10 incidents/month",
      "Basic AI analysis",
      "1 team member",
      "Email notifications",
    ],
  },
  {
    name: "Professional",
    price: "$99",
    period: "/month",
    description: "For growing teams",
    current: false,
    features: [
      "Unlimited incidents",
      "Advanced AI analysis",
      "Up to 10 team members",
      "Slack integration",
      "Priority support",
    ],
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "For large organizations",
    current: false,
    features: [
      "Everything in Professional",
      "Unlimited team members",
      "Custom integrations",
      "SLA guarantees",
      "Dedicated support",
    ],
  },
];

const BILLING_INFO = {
  current_plan: "Free",
  next_billing_date: null,
  payment_method: null,
  invoices: [
    {
      id: "inv_001",
      date: "2024-01-15",
      amount: "$0.00",
      status: "paid",
    },
  ],
};

export default function Billing() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-billing">
          Billing & Subscription
        </h1>
        <p className="text-muted-foreground mt-2">
          Manage your subscription and billing information
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {PLANS.map((plan) => (
          <Card
            key={plan.name}
            className={`relative hover-elevate ${
              plan.current ? "border-primary bg-primary/5" : ""
            }`}
            data-testid={`card-plan-${plan.name.toLowerCase()}`}
          >
            {plan.current && (
              <Badge className="absolute top-4 right-4" data-testid={`badge-current-plan`}>
                Current Plan
              </Badge>
            )}
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <CardDescription>{plan.description}</CardDescription>
              <div className="mt-4">
                <span className="text-3xl font-bold">{plan.price}</span>
                {plan.period && (
                  <span className="text-muted-foreground ml-2">{plan.period}</span>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-2">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-600" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button
                variant={plan.current ? "secondary" : "default"}
                className="w-full"
                data-testid={`button-${plan.current ? "manage" : "upgrade"}-${plan.name.toLowerCase()}`}
              >
                {plan.current ? "Manage" : "Upgrade"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Billing History</CardTitle>
          <CardDescription>View past invoices and payments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="grid grid-cols-4 gap-4 text-sm font-medium mb-4">
              <span>Date</span>
              <span>Amount</span>
              <span>Status</span>
              <span></span>
            </div>
            {BILLING_INFO.invoices.map((invoice) => (
              <div key={invoice.id} className="grid grid-cols-4 gap-4 text-sm py-2 border-b">
                <span>{invoice.date}</span>
                <span>{invoice.amount}</span>
                <Badge variant="outline">{invoice.status}</Badge>
                <Button variant="ghost" size="sm" data-testid={`button-invoice-${invoice.id}`}>
                  Download
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Payment Method</CardTitle>
          <CardDescription>Update your billing information</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            No payment method on file. Add one to upgrade your plan.
          </p>
          <Button data-testid="button-add-payment-method">
            Add Payment Method
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
