import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

const MOCK_ANALYTICS = {
  incidentsByMonth: [
    { month: "Jan", incidents: 12, resolved: 10 },
    { month: "Feb", incidents: 15, resolved: 13 },
    { month: "Mar", incidents: 8, resolved: 7 },
    { month: "Apr", incidents: 22, resolved: 18 },
    { month: "May", incidents: 18, resolved: 16 },
    { month: "Jun", incidents: 14, resolved: 14 },
  ],
  bySeverity: [
    { name: "Critical", value: 12, fill: "#dc2626" },
    { name: "High", value: 28, fill: "#f97316" },
    { name: "Medium", value: 45, fill: "#eab308" },
    { name: "Low", value: 35, fill: "#22c55e" },
  ],
  mttr: [
    { day: "Mon", mttr: 45 },
    { day: "Tue", mttr: 52 },
    { day: "Wed", mttr: 38 },
    { day: "Thu", mttr: 65 },
    { day: "Fri", mttr: 42 },
    { day: "Sat", mttr: 38 },
    { day: "Sun", mttr: 35 },
  ],
  stats: {
    total_incidents: 89,
    resolved_incidents: 78,
    avg_mttr: "2.3 hours",
    avg_severity: "Medium",
  },
};

export default function Analytics() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-analytics">
          Analytics & Reports
        </h1>
        <p className="text-muted-foreground mt-2">
          Track incident metrics and performance trends
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total Incidents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" data-testid="stat-total-incidents">
              {MOCK_ANALYTICS.stats.total_incidents}
            </div>
            <p className="text-xs text-muted-foreground mt-1">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Resolved</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" data-testid="stat-resolved">
              {MOCK_ANALYTICS.stats.resolved_incidents}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {Math.round((MOCK_ANALYTICS.stats.resolved_incidents / MOCK_ANALYTICS.stats.total_incidents) * 100)}% resolution rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Avg. MTTR</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" data-testid="stat-mttr">
              {MOCK_ANALYTICS.stats.avg_mttr}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Mean time to resolve</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Avg. Severity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" data-testid="stat-avg-severity">
              {MOCK_ANALYTICS.stats.avg_severity}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Average incident level</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Incidents Over Time</CardTitle>
            <CardDescription>Monthly incident trends</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={MOCK_ANALYTICS.incidentsByMonth}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="incidents" stroke="#0ea5e9" strokeWidth={2} />
                <Line type="monotone" dataKey="resolved" stroke="#22c55e" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Incidents by Severity</CardTitle>
            <CardDescription>Distribution across severity levels</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={MOCK_ANALYTICS.bySeverity}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {MOCK_ANALYTICS.bySeverity.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>MTTR by Day of Week</CardTitle>
          <CardDescription>Mean Time to Resolution trends</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={MOCK_ANALYTICS.mttr}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis label={{ value: "Minutes", angle: -90, position: "insideLeft" }} />
              <Tooltip />
              <Bar dataKey="mttr" fill="#0ea5e9" name="MTTR (minutes)" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
