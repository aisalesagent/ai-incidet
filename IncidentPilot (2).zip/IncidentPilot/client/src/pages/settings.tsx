import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
export default function Settings() {
  const [organizationName, setOrganizationName] = useState("My Organization");
  const [autoAssign, setAutoAssign] = useState(false);
  const [slackNotifications, setSlackNotifications] = useState(false);
  const [severity, setSeverity] = useState("medium");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-settings">
          Settings
        </h1>
        <p className="text-muted-foreground mt-2">
          Configure your organization settings and preferences
        </p>
      </div>
          <Card>
            <CardHeader>
              <CardTitle>Organization</CardTitle>
              <CardDescription>Basic organization information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="org-name">Organization Name</Label>
                <Input
                  id="org-name"
                  value={organizationName}
                  onChange={(e) => setOrganizationName(e.target.value)}
                  data-testid="input-org-name"
                />
              </div>
              <div>
                <Label htmlFor="org-slug">Organization Slug</Label>
                <Input
                  id="org-slug"
                  value={organizationName.toLowerCase().replace(/\s+/g, "-")}
                  disabled
                  data-testid="input-org-slug"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Used in URLs and API calls
                </p>
              </div>
              <Button data-testid="button-save-organization">
                Save Changes
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Incident Defaults</CardTitle>
              <CardDescription>Default settings for new incidents</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="default-severity">Default Severity</Label>
                <Select value={severity} onValueChange={setSeverity}>
                  <SelectTrigger id="default-severity" data-testid="select-default-severity">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto-assign" className="mb-1 cursor-pointer">
                    Auto-assign Incidents
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Automatically assign incidents to on-call engineer
                  </p>
                </div>
                <Switch
                  id="auto-assign"
                  checked={autoAssign}
                  onCheckedChange={setAutoAssign}
                  data-testid="switch-auto-assign"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>Configure how you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="slack-notif" className="mb-1 cursor-pointer">
                    Slack Notifications
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Send incident updates to Slack
                  </p>
                </div>
                <Switch
                  id="slack-notif"
                  checked={slackNotifications}
                  onCheckedChange={setSlackNotifications}
                  data-testid="switch-slack-notifications"
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="email-notif" className="mb-1 cursor-pointer">
                    Email Notifications
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Receive email alerts for critical incidents
                  </p>
                </div>
                <Switch
                  id="email-notif"
                  defaultChecked
                  data-testid="switch-email-notifications"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Danger Zone</CardTitle>
              <CardDescription>Irreversible actions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Delete Organization</p>
                  <p className="text-sm text-muted-foreground">
                    This will permanently delete all incidents and data
                  </p>
                </div>
                <Button
                  variant="destructive"
                  data-testid="button-delete-organization"
                >
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
    </div>
  );
}
