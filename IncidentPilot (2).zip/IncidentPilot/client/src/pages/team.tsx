import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Plus, Mail, Shield } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const MOCK_TEAM = [
  {
    id: "1",
    name: "You",
    email: "you@company.com",
    role: "owner",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=you",
  },
  {
    id: "2",
    name: "Alice Chen",
    email: "alice@company.com",
    role: "admin",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=alice",
  },
  {
    id: "3",
    name: "Bob Smith",
    email: "bob@company.com",
    role: "member",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=bob",
  },
];

const getRoleBadgeColor = (role: string) => {
  switch (role) {
    case "owner":
      return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
    case "admin":
      return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
    default:
      return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
  }
};

export default function Team() {
  const [email, setEmail] = useState("");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-team">
          Team Members
        </h1>
        <p className="text-muted-foreground mt-2">
          Manage team access and permissions
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Invite Team Member</CardTitle>
          <CardDescription>Add new members to your organization</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              placeholder="Enter email address"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              data-testid="input-invite-email"
            />
            <Button
              onClick={() => {
                setEmail("");
              }}
              data-testid="button-send-invite"
            >
              <Plus className="h-4 w-4 mr-2" />
              Send Invite
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-2">
        {MOCK_TEAM.map((member) => (
          <Card key={member.id} className="hover-elevate">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={member.avatar} />
                    <AvatarFallback>{member.name.split(" ")[0][0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium" data-testid={`text-member-name-${member.id}`}>
                      {member.name}
                    </p>
                    <p className="text-sm text-muted-foreground">{member.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={getRoleBadgeColor(member.role)} data-testid={`badge-role-${member.id}`}>
                    {member.role.charAt(0).toUpperCase() + member.role.slice(1)}
                  </Badge>
                  {member.id !== "1" && (
                    <Button
                      variant="ghost"
                      size="sm"
                      data-testid={`button-remove-${member.id}`}
                    >
                      Remove
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Role Permissions</CardTitle>
          <CardDescription>What each role can do</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {["owner", "admin", "member"].map((role) => (
              <div key={role} className="text-sm">
                <p className="font-medium mb-2 capitalize">{role}</p>
                <ul className="text-xs text-muted-foreground space-y-1 ml-4">
                  {role === "owner" && (
                    <>
                      <li>• Full access and billing management</li>
                      <li>• Add/remove team members</li>
                      <li>• Manage organization settings</li>
                    </>
                  )}
                  {role === "admin" && (
                    <>
                      <li>• Create and manage incidents</li>
                      <li>• Add/remove team members</li>
                      <li>• View analytics and reports</li>
                    </>
                  )}
                  {role === "member" && (
                    <>
                      <li>• Create and manage incidents</li>
                      <li>• View team incidents</li>
                    </>
                  )}
                </ul>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
