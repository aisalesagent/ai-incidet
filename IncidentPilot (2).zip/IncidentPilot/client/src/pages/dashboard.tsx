import { useMemo } from "react";
import { MetricsCard } from "@/components/metrics-card";
import { IncidentCard } from "@/components/incident-card";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Clock, CheckCircle2, TrendingUp, Plus, Loader2 } from "lucide-react";
import { Link } from "wouter";
import { useIncidents } from "@/hooks/use-incidents";
import { useCurrentOrganization } from "@/hooks/use-auth";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";

// Mock data - will be replaced with real data from API
const incidentTrendData = [
  { month: "Jan", incidents: 12 },
  { month: "Feb", incidents: 19 },
  { month: "Mar", incidents: 15 },
  { month: "Apr", incidents: 25 },
  { month: "May", incidents: 22 },
  { month: "Jun", incidents: 18 },
];

const severityData = [
  { name: "Critical", value: 3, color: "#ef4444" },
  { name: "High", value: 8, color: "#f97316" },
  { name: "Medium", value: 15, color: "#eab308" },
  { name: "Low", value: 10, color: "#3b82f6" },
];

const mttrData = [
  { month: "Jan", hours: 4.2 },
  { month: "Feb", hours: 3.8 },
  { month: "Mar", hours: 3.5 },
  { month: "Apr", hours: 4.1 },
  { month: "May", hours: 3.2 },
  { month: "Jun", hours: 2.9 },
];

const recentIncidents = [
  {
    id: "inc-001",
    title: "Production database connection timeout",
    status: "investigating" as const,
    severity: "critical" as const,
    assignedTo: { name: "Sarah Chen", avatar: "" },
    tags: ["database", "production"],
    createdAt: new Date(Date.now() - 30 * 60 * 1000),
  },
  {
    id: "inc-002",
    title: "API rate limiting errors in payment service",
    status: "open" as const,
    severity: "high" as const,
    assignedTo: { name: "Mike Johnson", avatar: "" },
    tags: ["api", "payment"],
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
  },
  {
    id: "inc-003",
    title: "Slow page load times on dashboard",
    status: "resolved" as const,
    severity: "medium" as const,
    assignedTo: { name: "Alex Kim", avatar: "" },
    tags: ["performance", "frontend"],
    createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
  },
];

export default function Dashboard() {
  const { organizationId } = useCurrentOrganization();
  const { data: allIncidents = [], isLoading } = useIncidents(organizationId);

  const metrics = useMemo(() => {
    const incidents = allIncidents || [];
    const openCount = incidents.filter((i: any) => ["open", "investigating"].includes(i.status)).length;
    const resolvedCount = incidents.filter((i: any) => i.status === "resolved").length;
    const criticalCount = incidents.filter((i: any) => i.severity === "critical").length;
    
    return {
      openCount,
      resolvedCount,
      criticalCount,
      avgResolutionTime: "2.9h",
    };
  }, [allIncidents]);

  const recentIncidentsData = useMemo(() => {
    return (allIncidents || []).slice(0, 3);
  }, [allIncidents]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight" data-testid="heading-dashboard">
            Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">
            Overview of your incident management metrics
          </p>
        </div>
        <Link href="/incidents/new">
          <Button className="gap-2" data-testid="button-create-incident">
            <Plus className="h-4 w-4" />
            Create Incident
          </Button>
        </Link>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <MetricsCard
          title="Open Incidents"
          value={metrics.openCount}
          change={12}
          icon={AlertCircle}
        />
        <MetricsCard
          title="Avg. Resolution Time"
          value={metrics.avgResolutionTime}
          change={-15}
          icon={Clock}
        />
        <MetricsCard
          title="Resolved This Month"
          value={metrics.resolvedCount}
          change={8}
          icon={CheckCircle2}
        />
        <MetricsCard
          title="Critical Incidents"
          value={metrics.criticalCount}
          change={-25}
          icon={TrendingUp}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Incident Trend</CardTitle>
            <CardDescription>Monthly incident count over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={incidentTrendData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis
                  dataKey="month"
                  className="text-xs"
                  tick={{ fill: "hsl(var(--muted-foreground))" }}
                />
                <YAxis
                  className="text-xs"
                  tick={{ fill: "hsl(var(--muted-foreground))" }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--popover))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "var(--radius)",
                  }}
                />
                <Bar dataKey="incidents" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Severity Distribution</CardTitle>
            <CardDescription>Current incidents by severity level</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={severityData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {severityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--popover))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "var(--radius)",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="ml-4 space-y-2">
              {severityData.map((item) => (
                <div key={item.name} className="flex items-center gap-2">
                  <div
                    className="h-3 w-3 rounded-sm"
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <span className="text-sm text-muted-foreground">
                    {item.name}: {item.value}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Mean Time to Resolve (MTTR)</CardTitle>
            <CardDescription>Average resolution time in hours</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={mttrData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis
                  dataKey="month"
                  className="text-xs"
                  tick={{ fill: "hsl(var(--muted-foreground))" }}
                />
                <YAxis
                  className="text-xs"
                  tick={{ fill: "hsl(var(--muted-foreground))" }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--popover))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "var(--radius)",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="hours"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--primary))", r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
          <div>
            <CardTitle>Recent Incidents</CardTitle>
            <CardDescription>Latest incidents across all teams</CardDescription>
          </div>
          <Link href="/incidents">
            <Button variant="outline" size="sm" data-testid="button-view-all">
              View All
            </Button>
          </Link>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <div className="text-center py-8">
              <Loader2 className="h-8 w-8 mx-auto text-muted-foreground animate-spin" />
            </div>
          ) : recentIncidentsData.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No incidents yet</p>
          ) : (
            recentIncidentsData.map((incident: any) => (
              <IncidentCard key={incident.id} {...incident} />
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
