# AI Incident Management SaaS

A complete incident management platform designed for DevOps and SRE teams to manage, track, and resolve production incidents with AI-powered analysis.

## Overview

This application combines real-time incident tracking with AI-powered analysis to help teams quickly identify root causes, predict severity, and generate actionable insights during critical situations. Built with React, Node.js/Express, PostgreSQL, and Google Gemini AI.

**Key Features:**
- 🚨 Real-time incident tracking and lifecycle management
- 🤖 AI-powered severity prediction and root cause analysis
- 👥 Multi-organization workspaces with role-based access control
- 🔗 OAuth integrations with GitHub, Jira, and Slack
- 🔔 Real-time notifications via WebSocket
- 📊 Analytics and incident reporting
- 🌙 Dark/light theme support
- 📱 Responsive UI built with shadcn/ui and Tailwind CSS

---

## Prerequisites

- Node.js 18+
- PostgreSQL 12+ (self-hosted or managed service)
- Google Gemini API key
- Redis (optional, for job queue support)

---

## Installation & Setup

### 1. Clone and Install Dependencies

```bash
git clone <your-repo-url>
cd incident-management
npm install
```

### 2. Configure Environment Variables

Create a `.env` file in the project root with your infrastructure details:

```env
# Database (PostgreSQL)
DATABASE_URL=postgresql://user:password@localhost:5432/incident_db
PGHOST=localhost
PGPORT=5432
PGUSER=your_db_user
PGPASSWORD=your_db_password
PGDATABASE=incident_db

# AI/ML Services
GEMINI_API_KEY=your_gemini_api_key

# Authentication (optional, for Clerk)
CLERK_SECRET_KEY=your_clerk_secret_key
CLERK_PUBLISHABLE_KEY=your_clerk_public_key

# Session Management
SESSION_SECRET=generate_a_random_secret_key_here

# Node Environment
NODE_ENV=production
PORT=5000
```

### 3. Set Up Database

```bash
# Run database migrations
npm run db:push
```

This creates all necessary tables in your PostgreSQL database.

### 4. Build for Production

```bash
npm run build
```

This compiles the React frontend and bundles the backend into a production-ready build in the `dist/` directory.

---

## Running the Application

### Development Mode

```bash
npm run dev
```

Starts the development server with hot reloading:
- Frontend: Vite dev server at http://localhost:5000
- Backend: Express API with live reload
- Database: Uses your configured PostgreSQL

### Production Mode

```bash
npm run build
npm start
```

Runs the production-built application on port 5000 (configurable via PORT env var).

---

## Deployment Guide

### Option 1: Docker (Recommended)

Create a `Dockerfile`:

```dockerfile
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy built application
COPY dist ./dist
COPY node_modules ./node_modules

# Set environment
ENV NODE_ENV=production
EXPOSE 5000

# Start server
CMD ["npm", "start"]
```

Build and run:

```bash
docker build -t incident-manager .
docker run -p 5000:5000 \
  -e DATABASE_URL="postgresql://..." \
  -e GEMINI_API_KEY="..." \
  -e SESSION_SECRET="..." \
  incident-manager
```

### Option 2: Traditional VPS/Server

1. SSH into your server
2. Install Node.js 18+
3. Install PostgreSQL or connect to managed PostgreSQL
4. Clone the repository
5. Set environment variables
6. Run `npm run build && npm start`
7. Use a process manager (PM2, systemd) to keep the app running
8. Use Nginx/Apache as a reverse proxy

Example PM2 setup:

```bash
npm install -g pm2
pm2 start npm --name "incident-manager" -- start
pm2 save
pm2 startup
```

### Option 3: Heroku, Railway, Render, etc.

Most hosting platforms support:

```bash
# Build automatically detects Node.js
npm run build
npm start
```

Configure environment variables in the platform's dashboard.

### Option 4: Kubernetes

Create a deployment manifest:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: incident-manager
spec:
  replicas: 3
  selector:
    matchLabels:
      app: incident-manager
  template:
    metadata:
      labels:
        app: incident-manager
    spec:
      containers:
      - name: incident-manager
        image: your-registry/incident-manager:latest
        ports:
        - containerPort: 5000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: database-url
        - name: GEMINI_API_KEY
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: gemini-api-key
```

---

## Using the Application

### 1. First Login

1. Navigate to your app URL
2. Click "Create Account"
3. Sign up with email and password
4. You'll be automatically logged in

### 2. Dashboard Overview

After login, you'll see:
- **Incident List**: All incidents for your organization
- **Status Breakdown**: By status (Draft, Open, Investigating, Resolved, Closed)
- **Quick Stats**: Incident counts and severity distribution
- **Recent Activity**: Latest incident updates

### 3. Creating an Incident

1. Click **"New Incident"** button
2. Enter:
   - **Title**: Brief description
   - **Description**: Detailed information
   - **Severity**: Critical, High, Medium, Low
   - **Status**: Current incident status
3. Click **"Create"**

### 4. AI-Powered Analysis

For any incident:
1. Click the incident to view details
2. Scroll to **"AI Analysis"** section
3. Click **"Analyze Incident"**
4. Gemini AI generates:
   - Severity prediction with confidence
   - Root cause analysis
   - Impact assessment
   - Action recommendations
   - Postmortem reports

### 5. Integrations

Go to **Integrations** page to connect:
- **GitHub**: Auto-create issues from incidents
- **Jira**: Sync with Jira tickets
- **Slack**: Send notifications to Slack

### 6. User Menu

Click your profile icon (top right) to:
- **Profile**: View/edit your account
- **Billing**: Manage subscription (if using)
- **Settings**: Change preferences
- **Log Out**: Sign out

---

## Project Structure

```
.
├── client/                 # React frontend
│   ├── src/
│   │   ├── pages/         # Page components
│   │   ├── components/    # UI components
│   │   ├── lib/           # Utilities
│   │   └── index.css      # Global styles
│   └── index.html         # HTML entry
│
├── server/                 # Node.js/Express backend
│   ├── routes/            # API endpoints
│   ├── middleware/        # Auth, logging, etc.
│   ├── storage.ts         # Database layer
│   ├── index-dev.ts       # Dev server setup
│   ├── index-prod.ts      # Prod server setup
│   └── app.ts             # Express app
│
├── shared/                 # Shared code
│   ├── schema.ts          # Data models
│   └── types.ts           # TypeScript types
│
├── dist/                   # Production build
├── vite.config.ts         # Vite config
├── tailwind.config.ts     # Tailwind config
├── drizzle.config.ts      # Database config
└── package.json           # Dependencies
```

---

## API Reference

### Authentication

```
POST   /api/auth/signup       - Create account
POST   /api/auth/login        - Login
```

### Incidents

```
GET    /api/incidents         - List incidents
POST   /api/incidents         - Create incident
GET    /api/incidents/:id     - Get incident details
PATCH  /api/incidents/:id     - Update incident
DELETE /api/incidents/:id     - Delete incident
```

### AI Analysis

```
POST   /api/incidents/:id/analyze   - Run AI analysis
```

### Organizations

```
GET    /api/organizations     - List organizations
POST   /api/organizations     - Create organization
PATCH  /api/organizations/:id - Update organization
```

### Integrations

```
GET    /api/integrations           - List integrations
POST   /api/integrations           - Connect integration
PATCH  /api/integrations/:id       - Update integration
DELETE /api/integrations/:id       - Disconnect integration
```

### Notifications

```
GET    /api/notifications              - Get notifications
PATCH  /api/notifications/:id/read     - Mark as read
```

### Analytics

```
GET    /api/analytics/incidents   - Incident stats
GET    /api/analytics/severity    - Severity breakdown
GET    /api/analytics/timeline    - Timeline data
```

---

## Database Schema

Core tables:
- **users** - User accounts
- **organizations** - Workspaces
- **organization_members** - User roles
- **incidents** - Incident records
- **incident_activities** - Activity timeline
- **notifications** - User notifications
- **integrations** - OAuth tokens
- **audit_logs** - Compliance logs

---

## Technology Stack

**Frontend:**
- React 18 + TypeScript
- Vite (build tool)
- Tailwind CSS + Shadcn/ui
- React Query (state management)
- Wouter (routing)

**Backend:**
- Express.js + TypeScript
- Node.js 18+
- PostgreSQL (Drizzle ORM)
- WebSocket (real-time)
- BullMQ (job queue)

**AI/ML:**
- Google Gemini API

---

## Development Workflow

### Making Changes

**Frontend** (auto-reload in dev):
```bash
# Edit files in client/src/
npm run dev
```

**Backend** (auto-restart in dev):
```bash
# Edit files in server/
npm run dev
```

**Database** (migrations):
```bash
# Update schema in shared/schema.ts
npm run db:push
```

### Building Components

```tsx
// client/src/components/MyComponent.tsx
export function MyComponent() {
  return <div>{/* Your component */}</div>;
}
```

### Adding API Routes

```ts
// server/routes.ts
app.post("/api/my-endpoint", requireAuth, async (req: AuthRequest, res) => {
  try {
    const data = validateSchema.parse(req.body);
    const result = await storage.operation(data);
    res.json(result);
  } catch (error) {
    res.status(400).json({ error: "Failed" });
  }
});
```

---

## Troubleshooting

### Blank Page / Won't Load

1. Check browser console (F12 → Console)
2. Check network requests (F12 → Network)
3. Verify DATABASE_URL is set correctly
4. Check backend logs

### Authentication Errors

1. Verify auth token is stored: `sessionStorage.getItem("app_auth_token")`
2. Check backend logs
3. Ensure auth endpoints are responding

### Database Connection Issues

1. Verify DATABASE_URL connection string
2. Ensure PostgreSQL is running
3. Check firewall/security group rules
4. Verify database credentials

### AI Analysis Not Working

1. Verify GEMINI_API_KEY is set
2. Check API key has proper permissions
3. Ensure incident has data for analysis
4. Check backend logs for API errors

---

## Performance Optimization

### For Production

1. **Enable Caching**
   - Set cache headers in Nginx/reverse proxy
   - Use React Query cache strategies

2. **Database Optimization**
   - Add indexes on frequently queried columns
   - Use connection pooling

3. **Static Assets**
   - Use CDN for frontend assets
   - Enable gzip compression

4. **Monitoring**
   - Set up application logs
   - Monitor database query performance
   - Track API response times

---

## Security Best Practices

1. **Environment Variables**
   - Never commit `.env` to version control
   - Use `.env.example` for documentation
   - Rotate SESSION_SECRET regularly

2. **Database**
   - Use strong passwords
   - Restrict network access
   - Enable SSL connections

3. **API**
   - Use HTTPS in production
   - Enable CORS only for trusted origins
   - Implement rate limiting

4. **Authentication**
   - Use long session timeouts
   - Implement token refresh
   - Monitor suspicious activity

---

## Support & Documentation

- `replit.md` - Architecture decisions
- `shared/schema.ts` - Data models
- `server/storage.ts` - Database operations
- Backend logs - Troubleshooting

---

## License

This project is proprietary and for internal use only.

---

## Next Steps

1. Set up PostgreSQL database
2. Configure environment variables
3. Build and deploy to your infrastructure
4. Set up domain and SSL certificate
5. Configure backups and monitoring
6. Start tracking incidents!

Happy incident tracking! 🚀
