# AI Incident Management SaaS - Design Guidelines

## Design Approach

**System-Based Approach** with inspiration from:
- **Linear**: Clean incident management, status indicators, command palette
- **Notion**: Collaborative workspace patterns, sidebar navigation
- **DataDog/PagerDuty**: Real-time monitoring dashboards, severity visualization

**Rationale**: Utility-focused productivity tool requiring efficiency, consistency, and rapid information access during critical incidents.

## Core Design Principles

1. **Clarity Under Pressure**: Every element optimized for quick comprehension during incidents
2. **Information Density**: Maximize actionable data without overwhelming users
3. **Status-First Design**: Incident state and severity immediately apparent
4. **Contextual Hierarchy**: Critical information surfaces automatically based on user role and current task

## Typography

**Font Stack**: Inter (primary), JetBrains Mono (code/technical)

**Hierarchy**:
- Page Titles: text-3xl, font-semibold
- Section Headers: text-xl, font-semibold
- Card Titles: text-lg, font-medium
- Body Text: text-base, font-normal
- Labels/Meta: text-sm, font-medium
- Technical Data: text-sm, font-mono
- Timestamps: text-xs, font-normal

## Layout System

**Spacing Units**: Tailwind 2, 4, 6, 8, 12, 16 for consistent rhythm

**Grid Structure**:
- Dashboard: 12-column responsive grid
- Sidebar: Fixed 256px width (desktop), collapsible mobile
- Main Content: max-w-7xl with px-6 lg:px-8
- Cards: p-6, gap-6 between elements
- Forms: p-8, gap-4 between fields

## Component Library

### Navigation & Layout

**Top Navigation Bar**:
- Fixed header, h-16, border-b
- Logo/brand (left), organization switcher (center-left), user menu + notifications (right)
- Breadcrumbs below header for context

**Sidebar Navigation**:
- Collapsible sections: Dashboard, Incidents, Analytics, Integrations, Settings
- Active state with subtle indicator bar
- Icon + label pattern
- Bottom section: Upgrade CTA, docs link

**Organization Switcher**:
- Dropdown with search, shows org name + avatar
- Quick access to recent organizations
- "Create New Organization" action

### Dashboard Components

**Metrics Cards**:
- Grid layout: grid-cols-1 md:grid-cols-2 lg:grid-cols-4
- Each card: rounded-lg border, p-6
- Metric value: text-3xl font-bold
- Label: text-sm, secondary text
- Trend indicator: icon + percentage change

**Chart Containers**:
- Section heading + time range selector (right-aligned)
- Chart area: min-h-[400px], p-6
- Legend below chart

**Recent Incidents Table**:
- Striped rows for readability
- Columns: Status badge, Severity, Title, Assignee avatar, Time
- Hover state for row interaction
- "View All" link in header

### Incident Management

**Incident List View**:
- Filters bar: Status, Severity, Assignee, Date range (sticky top)
- Bulk actions toolbar (appears on selection)
- Card-based layout on mobile, table on desktop
- Infinite scroll pagination

**Incident Card (List)**:
- Status badge (left), severity indicator
- Title (text-lg font-medium), truncate with tooltip
- Meta row: Assignee, created time, tags
- Quick actions: Edit, Clone, Archive

**Incident Detail Page**:
- Hero section: Full-width header with gradient background
- Title (text-4xl), status + severity badges, action buttons (right)
- Three-column layout below: Timeline (left sidebar 320px), Main content (center), Activity feed (right sidebar 320px)
- Tabs: Overview, RCA, Action Plan, Postmortem, Integrations

**AI-Generated Content Cards**:
- Distinct visual treatment with subtle border accent
- "AI Generated" badge
- Regenerate + feedback actions
- Expandable sections for long content

### Forms & Inputs

**Incident Creation Form**:
- Two-column layout on desktop
- Required fields marked clearly
- Severity selector: Large button group with visual differentiation
- Auto-save indicator
- AI suggestions panel (right sidebar)

**Input Patterns**:
- Floating labels for text inputs
- Icon prefixes where contextual
- Inline validation with micro-animations
- Rich text editor for descriptions (toolbar sticky)

### Status & Severity Indicators

**Status Badges**:
- Pill-shaped, px-3 py-1, text-xs font-medium uppercase tracking-wide
- Draft, Open, Investigating, Resolved, Closed states

**Severity Levels**:
- Visual weight progression: Critical > High > Medium > Low
- Used in badges, row highlights, and charts

### Real-Time Features

**Live Updates**:
- Toast notifications (top-right): slide-in animation
- Inline pulse indicators for new content
- "N new updates" banner (sticky, dismissible)

**Typing Indicators**:
- Small avatar cluster showing active users
- "User is typing..." below comment box

### Admin Panel

**User Management Table**:
- Advanced filters and search
- Inline editing for roles
- Bulk actions toolbar

**Billing Dashboard**:
- Current plan card (prominent)
- Usage meters with visual progress bars
- Invoice table with download actions

### Integrations

**Integration Cards**:
- Grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Logo, name, status badge
- "Connect" or "Configure" CTA
- Connected state shows activity count

**Integration Detail**:
- Connection status hero
- Configuration form
- Activity log table
- Sync history timeline

## Interactive Patterns

**Command Palette**:
- Triggered by Cmd/Ctrl+K
- Full-screen overlay with centered search
- Recent actions, quick navigation, create shortcuts

**Modals**:
- Centered, max-w-2xl for forms
- Full-screen on mobile
- Slide-up animation

**Dropdowns**:
- Attached to trigger, max-h-96 with scroll
- Keyboard navigation support

## Data Visualization

**Charts**:
- Line charts for trends over time
- Bar charts for comparison metrics
- Donut charts for distribution (severity, status)
- Minimal gridlines, clear axis labels

## Animations

Use sparingly, performance-first:
- Page transitions: fade
- Modals: slide-up (100ms)
- Dropdowns: scale + fade (150ms)
- Loading states: skeleton screens (no spinners except in buttons)

## Images

**Hero Section** (Marketing/Landing pages only):
- Large hero image showing dashboard interface screenshot
- Overlaid headline + CTA with backdrop blur
- Height: min-h-[600px]

**Dashboard**: No hero images
**Application**: Product screenshots in integration cards, user avatars throughout