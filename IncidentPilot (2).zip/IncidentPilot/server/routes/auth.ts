import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import crypto from "crypto";

const router = Router();

// Simple in-memory user storage for auth (in production, use database)
const users: Record<string, { email: string; password: string; firstName: string; lastName: string; id: string }> = {};

router.post("/login", async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password required" });
    }

    const user = Object.values(users).find((u) => u.email === email);

    if (!user || user.password !== password) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    // Create a token
    const token = `auth_${user.id}_${Date.now()}`;
    res.json({ token, userId: user.id });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Login failed" });
  }
});

router.post("/signup", async (req: Request, res: Response) => {
  try {
    const { email, password, firstName, lastName } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password required" });
    }

    if (Object.values(users).some((u) => u.email === email)) {
      return res.status(409).json({ error: "Email already exists" });
    }

    const userId = `user_${crypto.randomBytes(8).toString("hex")}`;
    users[userId] = { email, password, firstName: firstName || "", lastName: lastName || "", id: userId };

    const token = `auth_${userId}_${Date.now()}`;
    res.json({ token, userId });
  } catch (error) {
    console.error("Signup error:", error);
    res.status(500).json({ error: "Signup failed" });
  }
});

export default router;
