/**
 * OAuth Routes - Production OAuth integrations
 */

import { Router, type Request, type Response } from "express";
import { storage } from "../storage";
import { RealOAuthService, OAuthConfigError } from "../services/oauth-real";
import { requireAuth, type AuthRequest } from "../middleware/auth";
import crypto from "crypto";

const router = Router();
const oauthStates = new Map<string, { type: string; userId: string; orgId: string; createdAt: number }>();

// Debug endpoint - shows what redirect URIs will be used
router.get("/debug", (req: Request, res: Response) => {
  const requestHost = req.get('host');
  const protocol = requestHost?.includes('localhost') ? 'http' : 'https';
  const baseUrl = `${protocol}://${requestHost}`;
  
  res.json({
    requestHost,
    baseUrl,
    callbackUrls: {
      github: `${baseUrl}/api/oauth/github/callback`,
      jira: `${baseUrl}/api/oauth/jira/callback`,
      slack: `${baseUrl}/api/oauth/slack/callback`,
    },
  });
});

// Cleanup expired states every 5 minutes
setInterval(() => {
  const now = Date.now();
  const entries = Array.from(oauthStates.entries());
  for (const [state, data] of entries) {
    if (now - data.createdAt > 5 * 60 * 1000) {
      oauthStates.delete(state);
    }
  }
}, 5 * 60 * 1000);

router.get("/authorize", requireAuth, (req: AuthRequest, res: Response) => {
  try {
    const { provider, organizationId } = req.query;

    if (!provider || !organizationId) {
      return res.status(400).json({ error: "Missing provider or organizationId" });
    }

    if (!["github", "jira", "slack"].includes(provider as string)) {
      return res.status(400).json({ error: "Invalid provider" });
    }

    const state = crypto.randomBytes(32).toString("hex");
    oauthStates.set(state, {
      type: provider as string,
      userId: req.auth!.userId,
      orgId: organizationId as string,
      createdAt: Date.now(),
    });

    const requestHost = req.get('host');
    let authUrl = "";
    try {
      switch (provider) {
        case "github":
          authUrl = RealOAuthService.getGitHubAuthUrl(state, requestHost);
          break;
        case "jira":
          authUrl = RealOAuthService.getJiraAuthUrl(state, requestHost);
          break;
        case "slack":
          authUrl = RealOAuthService.getSlackAuthUrl(state, requestHost);
          break;
      }
    } catch (configError) {
      if (configError instanceof OAuthConfigError) {
        return res.status(503).json({ error: configError.message });
      }
      throw configError;
    }

    res.json({ authUrl });
  } catch (error) {
    console.error("OAuth authorize error:", error);
    res.status(500).json({ error: "Failed to generate authorization URL" });
  }
});

router.get("/github/callback", async (req: Request, res: Response) => {
  try {
    const { code, state, error } = req.query;

    if (error) {
      return res.redirect(
        `${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=github&status=error`
      );
    }

    const stateData = oauthStates.get(state as string);
    if (!stateData) {
      return res.redirect(
        `${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=github&status=error`
      );
    }

    const requestHost = req.get('host');
    const tokenResponse = await RealOAuthService.exchangeGitHubCode(code as string, requestHost);
    const user = await RealOAuthService.getGitHubUser(tokenResponse.accessToken);

    await storage.createIntegration({
      organizationId: stateData.orgId,
      type: "github",
      name: `GitHub - ${user.login}`,
      config: {
        accessToken: RealOAuthService.encryptCredentials({
          accessToken: tokenResponse.accessToken,
          userId: user.id,
          login: user.login,
        }),
        username: user.login,
        avatarUrl: user.avatar_url,
        externalId: user.id.toString(),
      } as any,
      enabled: true,
    });

    oauthStates.delete(state as string);
    res.redirect(`${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=github&status=success`);
  } catch (error) {
    console.error("GitHub callback error:", error);
    res.redirect(`${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=github&status=error`);
  }
});

router.get("/jira/callback", async (req: Request, res: Response) => {
  try {
    const { code, state, error } = req.query;

    if (error) {
      return res.redirect(
        `${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=jira&status=error`
      );
    }

    const stateData = oauthStates.get(state as string);
    if (!stateData) {
      return res.redirect(
        `${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=jira&status=error`
      );
    }

    const requestHost = req.get('host');
    const tokenResponse = await RealOAuthService.exchangeJiraCode(code as string, requestHost);
    const user = await RealOAuthService.getJiraUser(tokenResponse.accessToken);

    await storage.createIntegration({
      organizationId: stateData.orgId,
      type: "jira",
      name: `Jira - ${user.email}`,
      config: {
        accessToken: RealOAuthService.encryptCredentials({
          accessToken: tokenResponse.accessToken,
          refreshToken: tokenResponse.refreshToken,
          accountId: user.account_id,
        }),
        email: user.email,
        accountId: user.account_id,
        externalId: user.account_id,
      } as any,
      enabled: true,
    });

    oauthStates.delete(state as string);
    res.redirect(`${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=jira&status=success`);
  } catch (error) {
    console.error("Jira callback error:", error);
    res.redirect(`${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=jira&status=error`);
  }
});

router.get("/slack/callback", async (req: Request, res: Response) => {
  try {
    const { code, state, error } = req.query;

    if (error) {
      return res.redirect(
        `${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=slack&status=error`
      );
    }

    const stateData = oauthStates.get(state as string);
    if (!stateData) {
      return res.redirect(
        `${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=slack&status=error`
      );
    }

    const requestHost = req.get('host');
    const tokenResponse = await RealOAuthService.exchangeSlackCode(code as string, requestHost);

    await storage.createIntegration({
      organizationId: stateData.orgId,
      type: "slack",
      name: "Slack Workspace",
      config: {
        accessToken: RealOAuthService.encryptCredentials({
          accessToken: tokenResponse.accessToken,
        }),
      } as any,
      enabled: true,
    });

    oauthStates.delete(state as string);
    res.redirect(`${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=slack&status=success`);
  } catch (error) {
    console.error("Slack callback error:", error);
    res.redirect(`${process.env.CLIENT_URL || "http://localhost:5000"}/integrations?provider=slack&status=error`);
  }
});

export default router;
