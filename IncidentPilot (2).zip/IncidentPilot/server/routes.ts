import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import express from "express";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import cors from "cors";
import { storage } from "./storage";
import { requireAuth, type AuthRequest } from "./middleware/auth";
import {
  insertIncidentSchema,
  insertOrganizationSchema,
  insertIntegrationSchema,
} from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import oauthRouter from "./routes/oauth";
import authRouter from "./routes/auth";

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: "Too many requests from this IP, please try again later.",
  skip: () => process.env.NODE_ENV === 'development', // Skip rate limiting in development
});

const strictLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: "Too many AI analysis requests, please try again later.",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Trust proxy in development (Replit uses proxies)
  if (process.env.NODE_ENV === 'development') {
    app.set('trust proxy', 1);
  }

  // Security middleware
  // In development, disable CSP to allow Vite's inline scripts
  // In production, apply full helmet protection
  app.use(helmet({
    contentSecurityPolicy: process.env.NODE_ENV === 'development' ? false : undefined,
    hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
  }));

  // CORS configuration
  app.use(cors({
    origin: process.env.CLIENT_URL || "*",
    credentials: true,
    methods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"],
  }));

  app.use(express.json());

  // Auth logging middleware for debugging
  app.use((req, res, next) => {
    const authHeader = req.headers.authorization;
    if (authHeader && req.path.startsWith("/api/")) {
      const hasToken = authHeader.startsWith("Bearer ");
      req.headers["x-has-auth"] = hasToken ? "true" : "false";
    }
    next();
  });

  // Apply rate limiting to all API routes
  app.use("/api/", limiter);

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // ==================== INCIDENT ROUTES ====================

  // Get all incidents for an organization
  app.get("/api/incidents", requireAuth, async (req: AuthRequest, res) => {
    try {
      const { organizationId, status, severity, assignedToId } = req.query;

      if (!organizationId) {
        return res.status(400).json({ error: "organizationId is required" });
      }

      const incidents = await storage.getIncidents(organizationId as string, {
        status: status as string,
        severity: severity as string,
        assignedToId: assignedToId as string,
      });

      res.json(incidents);
    } catch (error) {
      console.error("Error fetching incidents:", error);
      res.status(500).json({ error: "Failed to fetch incidents" });
    }
  });

  // Get single incident
  app.get("/api/incidents/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      const incident = await storage.getIncident(req.params.id);

      if (!incident) {
        return res.status(404).json({ error: "Incident not found" });
      }

      res.json(incident);
    } catch (error) {
      console.error("Error fetching incident:", error);
      res.status(500).json({ error: "Failed to fetch incident" });
    }
  });

  // Create incident
  app.post("/api/incidents", requireAuth, async (req: AuthRequest, res) => {
    try {
      const validatedData = insertIncidentSchema.parse(req.body);
      const incident = await storage.createIncident(validatedData);

      // Add activity log
      await storage.addIncidentActivity({
        incidentId: incident.id,
        userId: req.auth!.userId,
        type: "created",
        content: "Incident created",
      });

      // Add audit log
      await storage.addAuditLog({
        organizationId: incident.organizationId,
        userId: req.auth!.userId,
        action: "incident.created",
        resourceType: "incident",
        resourceId: incident.id,
        changes: { incident },
      });

      res.status(201).json(incident);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: validationError.message });
      }
      console.error("Error creating incident:", error);
      res.status(500).json({ error: "Failed to create incident" });
    }
  });

  // Update incident
  app.patch("/api/incidents/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      const oldIncident = await storage.getIncident(req.params.id);
      if (!oldIncident) {
        return res.status(404).json({ error: "Incident not found" });
      }

      const incident = await storage.updateIncident(req.params.id, req.body);

      // Track status changes
      if (req.body.status && req.body.status !== oldIncident.status) {
        await storage.addIncidentActivity({
          incidentId: incident!.id,
          userId: req.auth!.userId,
          type: "status_change",
          content: `Status changed from ${oldIncident.status} to ${req.body.status}`,
        });
      }

      // Track assignment changes
      if (req.body.assignedToId && req.body.assignedToId !== oldIncident.assignedToId) {
        await storage.addIncidentActivity({
          incidentId: incident!.id,
          userId: req.auth!.userId,
          type: "assigned",
          content: `Assigned to user`,
        });

        // Create notification for assigned user
        if (req.body.assignedToId) {
          await storage.createNotification({
            userId: req.body.assignedToId,
            organizationId: incident!.organizationId,
            type: "incident_assigned",
            title: "Incident assigned to you",
            message: `You have been assigned to: ${incident!.title}`,
            incidentId: incident!.id,
          });
        }
      }

      // Add audit log
      await storage.addAuditLog({
        organizationId: incident!.organizationId,
        userId: req.auth!.userId,
        action: "incident.updated",
        resourceType: "incident",
        resourceId: incident!.id,
        changes: { old: oldIncident, new: req.body },
      });

      res.json(incident);
    } catch (error) {
      console.error("Error updating incident:", error);
      res.status(500).json({ error: "Failed to update incident" });
    }
  });

  // Delete incident
  app.delete("/api/incidents/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      const incident = await storage.getIncident(req.params.id);
      if (!incident) {
        return res.status(404).json({ error: "Incident not found" });
      }

      await storage.deleteIncident(req.params.id);

      // Add audit log
      await storage.addAuditLog({
        organizationId: incident.organizationId,
        userId: req.auth!.userId,
        action: "incident.deleted",
        resourceType: "incident",
        resourceId: incident.id,
      });

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting incident:", error);
      res.status(500).json({ error: "Failed to delete incident" });
    }
  });

  // Get incident activities
  app.get("/api/incidents/:id/activities", requireAuth, async (req: AuthRequest, res) => {
    try {
      const activities = await storage.getIncidentActivities(req.params.id);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ error: "Failed to fetch activities" });
    }
  });

  // Trigger AI analysis for incident
  app.post("/api/incidents/:id/analyze", requireAuth, strictLimiter, async (req: AuthRequest, res) => {
    try {
      const incident = await storage.getIncident(req.params.id);
      if (!incident) {
        return res.status(404).json({ error: "Incident not found" });
      }

      // Queue AI analysis job
      const { queueAIAnalysis } = await import("./jobs/queue");
      const job = await queueAIAnalysis(
        incident.id,
        incident.organizationId,
        req.auth!.userId
      );

      res.json({
        message: "AI analysis queued",
        incidentId: incident.id,
        jobId: job.id,
      });
    } catch (error) {
      console.error("Error triggering AI analysis:", error);
      res.status(500).json({ error: "Failed to trigger AI analysis" });
    }
  });

  // ==================== ORGANIZATION ROUTES ====================

  // Get user's organizations
  app.get("/api/organizations", requireAuth, async (req: AuthRequest, res) => {
    try {
      const organizations = await storage.getUserOrganizations(req.auth!.userId);
      res.json(organizations);
    } catch (error) {
      console.error("Error fetching organizations:", error);
      res.status(500).json({ error: "Failed to fetch organizations" });
    }
  });

  // Get organization by ID
  app.get("/api/organizations/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      const organization = await storage.getOrganization(req.params.id);
      if (!organization) {
        return res.status(404).json({ error: "Organization not found" });
      }
      res.json(organization);
    } catch (error) {
      console.error("Error fetching organization:", error);
      res.status(500).json({ error: "Failed to fetch organization" });
    }
  });

  // Create organization
  app.post("/api/organizations", requireAuth, async (req: AuthRequest, res) => {
    try {
      const validatedData = insertOrganizationSchema.parse(req.body);
      const organization = await storage.createOrganization(validatedData);

      // Add creator as owner
      await storage.addOrganizationMember({
        organizationId: organization.id,
        userId: req.auth!.userId,
        role: "owner",
      });

      res.status(201).json(organization);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: validationError.message });
      }
      console.error("Error creating organization:", error);
      res.status(500).json({ error: "Failed to create organization" });
    }
  });

  // Update organization
  app.patch("/api/organizations/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      const organization = await storage.updateOrganization(req.params.id, req.body);
      if (!organization) {
        return res.status(404).json({ error: "Organization not found" });
      }
      res.json(organization);
    } catch (error) {
      console.error("Error updating organization:", error);
      res.status(500).json({ error: "Failed to update organization" });
    }
  });

  // Get organization members
  app.get("/api/organizations/:id/members", requireAuth, async (req: AuthRequest, res) => {
    try {
      const members = await storage.getOrganizationMembers(req.params.id);
      res.json(members);
    } catch (error) {
      console.error("Error fetching members:", error);
      res.status(500).json({ error: "Failed to fetch members" });
    }
  });

  // ==================== NOTIFICATION ROUTES ====================

  // Get user notifications
  app.get("/api/notifications", requireAuth, async (req: AuthRequest, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const notifications = await storage.getUserNotifications(req.auth!.userId, limit);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });

  // Mark notification as read
  app.patch("/api/notifications/:id/read", requireAuth, async (req: AuthRequest, res) => {
    try {
      await storage.markNotificationRead(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ error: "Failed to mark notification as read" });
    }
  });

  // Get unread notification count
  app.get("/api/notifications/unread/count", requireAuth, async (req: AuthRequest, res) => {
    try {
      const count = await storage.getUnreadNotificationCount(req.auth!.userId);
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread count:", error);
      res.status(500).json({ error: "Failed to fetch unread count" });
    }
  });

  // ==================== INTEGRATION ROUTES ====================

  // Get organization integrations
  app.get("/api/integrations", requireAuth, async (req: AuthRequest, res) => {
    try {
      const { organizationId } = req.query;
      if (!organizationId) {
        return res.status(400).json({ error: "organizationId is required" });
      }

      const integrations = await storage.getIntegrations(organizationId as string);
      res.json(integrations);
    } catch (error) {
      console.error("Error fetching integrations:", error);
      res.status(500).json({ error: "Failed to fetch integrations" });
    }
  });

  // Create integration
  app.post("/api/integrations", requireAuth, async (req: AuthRequest, res) => {
    try {
      const validatedData = insertIntegrationSchema.parse(req.body);
      const integration = await storage.createIntegration(validatedData);
      res.status(201).json(integration);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ error: validationError.message });
      }
      console.error("Error creating integration:", error);
      res.status(500).json({ error: "Failed to create integration" });
    }
  });

  // Update integration
  app.patch("/api/integrations/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      const integration = await storage.updateIntegration(req.params.id, req.body);
      if (!integration) {
        return res.status(404).json({ error: "Integration not found" });
      }
      res.json(integration);
    } catch (error) {
      console.error("Error updating integration:", error);
      res.status(500).json({ error: "Failed to update integration" });
    }
  });

  // Delete integration
  app.delete("/api/integrations/:id", requireAuth, async (req: AuthRequest, res) => {
    try {
      await storage.deleteIntegration(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting integration:", error);
      res.status(500).json({ error: "Failed to delete integration" });
    }
  });

  // Mount auth routes
  app.use("/api/auth", authRouter);

  // Mount OAuth routes
  app.use("/api/oauth", oauthRouter);

  // ==================== AUDIT LOG ROUTES ====================

  // Get audit logs
  app.get("/api/audit-logs", requireAuth, async (req: AuthRequest, res) => {
    try {
      const { organizationId } = req.query;
      if (!organizationId) {
        return res.status(400).json({ error: "organizationId is required" });
      }

      const limit = parseInt(req.query.limit as string) || 100;
      const logs = await storage.getAuditLogs(organizationId as string, limit);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching audit logs:", error);
      res.status(500).json({ error: "Failed to fetch audit logs" });
    }
  });

  // ==================== WEBSOCKET SERVER ====================

  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Track connected clients
  const clients = new Map<string, Set<WebSocket>>();

  wss.on('connection', (ws: WebSocket, req) => {
    console.log('WebSocket client connected');

    let userId: string | undefined;
    let organizationId: string | undefined;

    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message.toString());

        // Handle initial connection
        if (data.type === 'auth') {
          userId = data.userId;
          organizationId = data.organizationId;

          if (userId && organizationId) {
            const key = `${organizationId}:${userId}`;
            if (!clients.has(key)) {
              clients.set(key, new Set());
            }
            clients.get(key)!.add(ws);
            console.log(`User ${userId} joined organization ${organizationId}`);
          }
        }

        // Handle typing indicators
        if (data.type === 'typing') {
          broadcastToOrganization(organizationId, {
            type: 'user_typing',
            userId,
            incidentId: data.incidentId,
          }, ws);
        }

        // Handle presence updates
        if (data.type === 'presence') {
          broadcastToOrganization(organizationId, {
            type: 'user_presence',
            userId,
            status: data.status,
          }, ws);
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      if (userId && organizationId) {
        const key = `${organizationId}:${userId}`;
        const userClients = clients.get(key);
        if (userClients) {
          userClients.delete(ws);
          if (userClients.size === 0) {
            clients.delete(key);
          }
        }
        console.log(`User ${userId} disconnected from organization ${organizationId}`);
      }
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  });

  // Broadcast message to all clients in an organization except sender
  function broadcastToOrganization(organizationId: string | undefined, message: any, sender?: WebSocket) {
    if (!organizationId) return;

    clients.forEach((sockets, key) => {
      if (key.startsWith(organizationId + ':')) {
        sockets.forEach((client) => {
          if (client !== sender && client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(message));
          }
        });
      }
    });
  }

  console.log('✓ API routes registered');
  console.log('✓ WebSocket server initialized on /ws');

  return httpServer;
}

// Export function to broadcast incident updates
export function broadcastIncidentUpdate(organizationId: string, incident: any) {
  // This is defined outside the function - will be accessible to modules that import it
  // Implementation would be passed via closure in production
}
