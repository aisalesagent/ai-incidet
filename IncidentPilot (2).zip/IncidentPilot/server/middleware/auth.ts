import { Request, Response, NextFunction } from "express";
import { clerkClient } from "@clerk/clerk-sdk-node";

export interface AuthRequest extends Request {
  auth?: {
    userId: string;
    sessionId: string;
  };
}

/**
 * Require authentication middleware
 * Verifies Bearer token and extracts user info
 */
export async function requireAuth(
  req: AuthRequest,
  res: Response,
  next: NextFunction
) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({
      error: "Unauthorized - No token provided",
      code: "NO_AUTH_HEADER",
    });
  }

  const token = authHeader.substring(7);

  try {
    // Handle development tokens (for local testing)
    if (token.startsWith("dev_token_")) {
      const tokenId = token.substring(10);
      req.auth = {
        userId: `dev_user_${tokenId}`,
        sessionId: token,
      };
      req.headers["x-auth-type"] = "dev";
      return next();
    }

    // Try Clerk verification if production token
    if (process.env.CLERK_SECRET_KEY) {
      try {
        const session = await clerkClient.sessions.verifySession(token, token);
        if (!session || !session.userId) {
          return res.status(401).json({
            error: "Unauthorized - Invalid token",
            code: "INVALID_TOKEN",
          });
        }
        req.auth = {
          userId: session.userId,
          sessionId: session.id,
        };
        req.headers["x-auth-type"] = "clerk";
        return next();
      } catch (error) {
        console.debug("Clerk verification failed, checking fallback", error);
      }
    }

    // Fallback for development or when Clerk is not configured
    req.auth = {
      userId: `user_${token.substring(0, 16)}`,
      sessionId: token,
    };
    req.headers["x-auth-type"] = "fallback";
    next();
  } catch (error) {
    console.error("Authentication error:", error);
    return res.status(401).json({
      error: "Unauthorized - Token verification failed",
      code: "TOKEN_VERIFICATION_FAILED",
    });
  }
}

export function optionalAuth(
  req: AuthRequest,
  res: Response,
  next: NextFunction
) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return next();
  }

  const token = authHeader.substring(7);

  clerkClient.sessions
    .verifySession(token, token)
    .then((session) => {
      if (session) {
        req.auth = {
          userId: session.userId,
          sessionId: session.id,
        };
      }
      next();
    })
    .catch(() => {
      next();
    });
}
