/**
 * Stripe Service - Handles billing and payments
 */

export interface StripeConfig {
  apiKey: string;
  webhookSecret: string;
}

export interface StripeCustomer {
  id: string;
  email: string;
  name: string;
  subscriptionId?: string;
  plan: string;
  status: string;
}

export class StripeService {
  private apiKey: string;

  constructor() {
    this.apiKey = process.env.STRIPE_SECRET_KEY || "";
  }

  /**
   * Create Stripe customer
   */
  async createCustomer(email: string, name: string): Promise<any> {
    const response = await fetch("https://api.stripe.com/v1/customers", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${this.apiKey}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        email,
        name,
      }).toString(),
    });

    if (!response.ok) {
      throw new Error("Failed to create Stripe customer");
    }

    return response.json();
  }

  /**
   * Create subscription
   */
  async createSubscription(
    customerId: string,
    priceId: string
  ): Promise<any> {
    const response = await fetch(
      "https://api.stripe.com/v1/subscriptions",
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${this.apiKey}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          customer: customerId,
          items: JSON.stringify([{ price: priceId }]),
        }).toString(),
      }
    );

    if (!response.ok) {
      throw new Error("Failed to create subscription");
    }

    return response.json();
  }

  /**
   * Get subscription
   */
  async getSubscription(subscriptionId: string): Promise<any> {
    const response = await fetch(
      `https://api.stripe.com/v1/subscriptions/${subscriptionId}`,
      {
        headers: {
          "Authorization": `Bearer ${this.apiKey}`,
        },
      }
    );

    if (!response.ok) {
      throw new Error("Failed to fetch subscription");
    }

    return response.json();
  }

  /**
   * Create checkout session
   */
  async createCheckoutSession(
    customerId: string,
    priceId: string,
    successUrl: string,
    cancelUrl: string
  ): Promise<any> {
    const response = await fetch(
      "https://api.stripe.com/v1/checkout/sessions",
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${this.apiKey}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          customer: customerId,
          payment_method_types: "card",
          line_items: JSON.stringify([
            {
              price: priceId,
              quantity: 1,
            },
          ]),
          mode: "subscription",
          success_url: successUrl,
          cancel_url: cancelUrl,
        }).toString(),
      }
    );

    if (!response.ok) {
      throw new Error("Failed to create checkout session");
    }

    return response.json();
  }

  /**
   * Verify webhook signature
   */
  verifyWebhookSignature(
    body: string,
    signature: string
  ): boolean {
    // In production, use crypto to verify HMAC signature
    // For now, just validate signature exists
    return signature && signature.startsWith("t=");
  }
}

export const stripeService = new StripeService();
