import { GoogleGenAI } from "@google/genai";
import type { Incident } from "@shared/schema";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface SeverityPrediction {
  severity: "critical" | "high" | "medium" | "low";
  confidence: number;
  reasoning: string;
}

export interface RCAResult {
  rootCause: string;
  confidence: number;
}

export interface ImpactAssessment {
  assessment: string;
  confidence: number;
}

export interface ActionPlan {
  steps: string[];
  estimatedTime: string;
  priority: string;
}

export interface PostmortemReport {
  summary: string;
  timeline: Array<{
    time: string;
    event: string;
    type: string;
  }>;
  lessonsLearned: string[];
}

export class AIService {
  /**
   * Predict incident severity using AI analysis
   */
  async predictSeverity(incident: Incident): Promise<SeverityPrediction> {
    try {
      const prompt = `You are an incident management expert. Analyze this incident and predict its severity level.

Incident Details:
Title: ${incident.title}
Description: ${incident.description || "No description provided"}
Affected Users: ${incident.metadata?.affectedUsers || "Unknown"}
Service: ${incident.metadata?.service || "Unknown"}
Environment: ${incident.metadata?.environment || "Unknown"}

Based on the information above, determine the severity level (critical, high, medium, or low) and provide your confidence score (0-1) and brief reasoning.

Respond with JSON in this format:
{
  "severity": "critical" | "high" | "medium" | "low",
  "confidence": number between 0 and 1,
  "reasoning": "brief explanation"
}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash-001",
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              severity: { type: "string", enum: ["critical", "high", "medium", "low"] },
              confidence: { type: "number" },
              reasoning: { type: "string" },
            },
            required: ["severity", "confidence", "reasoning"],
          },
        },
        contents: prompt,
      });

      const result = JSON.parse(response.text);
      return result;
    } catch (error) {
      console.error("Error predicting severity:", error);
      throw new Error("Failed to predict severity");
    }
  }

  /**
   * Generate Root Cause Analysis
   */
  async generateRCA(incident: Incident): Promise<RCAResult> {
    try {
      const prompt = `You are an expert DevOps engineer performing a root cause analysis. Analyze this incident and determine the most likely root cause.

Incident Details:
Title: ${incident.title}
Description: ${incident.description || "No description provided"}
Severity: ${incident.severity}
Service: ${incident.metadata?.service || "Unknown"}
Environment: ${incident.metadata?.environment || "Unknown"}
Tags: ${incident.tags?.join(", ") || "None"}

Perform a thorough root cause analysis. Explain:
1. What is the most likely root cause?
2. What evidence supports this conclusion?
3. What underlying factors contributed to this issue?
4. How can we verify this hypothesis?

Provide a detailed but concise analysis (2-4 paragraphs).`;

      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash-001",
        contents: prompt,
      });

      return {
        rootCause: response.text,
        confidence: 0.85,
      };
    } catch (error) {
      console.error("Error generating RCA:", error);
      throw new Error("Failed to generate RCA");
    }
  }

  /**
   * Generate impact assessment
   */
  async generateImpactAssessment(incident: Incident): Promise<ImpactAssessment> {
    try {
      const prompt = `You are an incident management expert. Assess the business and technical impact of this incident.

Incident Details:
Title: ${incident.title}
Description: ${incident.description || "No description provided"}
Severity: ${incident.severity}
Status: ${incident.status}
Affected Users: ${incident.metadata?.affectedUsers || "Unknown"}
Service: ${incident.metadata?.service || "Unknown"}
Environment: ${incident.metadata?.environment || "Unknown"}

Provide a comprehensive impact assessment covering:
1. User impact (how many users affected, what functionality is impacted)
2. Business impact (revenue, reputation, compliance)
3. Technical impact (system availability, data integrity, performance)
4. Urgency and priority recommendations

Keep the assessment concise but thorough (2-3 paragraphs).`;

      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash-001",
        contents: prompt,
      });

      return {
        assessment: response.text,
        confidence: 0.88,
      };
    } catch (error) {
      console.error("Error generating impact assessment:", error);
      throw new Error("Failed to generate impact assessment");
    }
  }

  /**
   * Generate action plan with step-by-step remediation
   */
  async generateActionPlan(incident: Incident, rca?: string): Promise<ActionPlan> {
    try {
      const prompt = `You are a senior DevOps engineer creating an action plan to resolve this incident.

Incident Details:
Title: ${incident.title}
Description: ${incident.description || "No description provided"}
Severity: ${incident.severity}
Service: ${incident.metadata?.service || "Unknown"}
Environment: ${incident.metadata?.environment || "Unknown"}

${rca ? `Root Cause Analysis:\n${rca}\n` : ""}

Create a detailed action plan with:
1. Immediate mitigation steps to reduce impact
2. Steps to fully resolve the root cause
3. Verification steps to confirm resolution
4. Follow-up actions to prevent recurrence

Respond with JSON in this format:
{
  "steps": ["step 1", "step 2", ...],
  "estimatedTime": "estimated time to resolution (e.g., '2-3 hours')",
  "priority": "immediate" | "high" | "medium" | "low"
}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash-001",
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              steps: { type: "array", items: { type: "string" } },
              estimatedTime: { type: "string" },
              priority: { type: "string" },
            },
            required: ["steps", "estimatedTime", "priority"],
          },
        },
        contents: prompt,
      });

      const result = JSON.parse(response.text);
      return result;
    } catch (error) {
      console.error("Error generating action plan:", error);
      throw new Error("Failed to generate action plan");
    }
  }

  /**
   * Generate postmortem report
   */
  async generatePostmortem(incident: Incident, activities?: any[]): Promise<PostmortemReport> {
    try {
      const prompt = `You are creating a postmortem report for this resolved incident.

Incident Details:
Title: ${incident.title}
Description: ${incident.description || "No description provided"}
Severity: ${incident.severity}
Created: ${incident.createdAt}
Resolved: ${incident.resolvedAt || "Not yet resolved"}
Service: ${incident.metadata?.service || "Unknown"}
Environment: ${incident.metadata?.environment || "Unknown"}

Create a comprehensive postmortem report with:
1. Executive summary (2-3 sentences)
2. Timeline of events (key milestones from detection to resolution)
3. Lessons learned and recommendations for preventing similar incidents

Respond with JSON in this format:
{
  "summary": "executive summary",
  "timeline": [
    {"time": "HH:MM", "event": "description", "type": "detection|escalation|mitigation|resolution"},
    ...
  ],
  "lessonsLearned": ["lesson 1", "lesson 2", ...]
}`;

      const response = await ai.models.generateContent({
        model: "gemini-2.0-flash-001",
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              summary: { type: "string" },
              timeline: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    time: { type: "string" },
                    event: { type: "string" },
                    type: { type: "string" },
                  },
                  required: ["time", "event", "type"],
                },
              },
              lessonsLearned: { type: "array", items: { type: "string" } },
            },
            required: ["summary", "timeline", "lessonsLearned"],
          },
        },
        contents: prompt,
      });

      const result = JSON.parse(response.text);
      return result;
    } catch (error) {
      console.error("Error generating postmortem:", error);
      throw new Error("Failed to generate postmortem");
    }
  }

  /**
   * Perform complete AI analysis on an incident
   */
  async analyzeIncident(incident: Incident): Promise<any> {
    try {
      // Run analyses in parallel for efficiency
      const [severityPrediction, rca, impactAssessment] = await Promise.all([
        this.predictSeverity(incident),
        this.generateRCA(incident),
        this.generateImpactAssessment(incident),
      ]);

      // Generate action plan based on RCA
      const actionPlan = await this.generateActionPlan(incident, rca.rootCause);

      return {
        severityPrediction: {
          severity: severityPrediction.severity,
          confidence: severityPrediction.confidence,
        },
        rca: rca.rootCause,
        impactAssessment: impactAssessment.assessment,
        actionPlan: {
          steps: actionPlan.steps,
          estimatedTime: actionPlan.estimatedTime,
        },
      };
    } catch (error) {
      console.error("Error analyzing incident:", error);
      throw new Error("Failed to analyze incident");
    }
  }
}

export const aiService = new AIService();
