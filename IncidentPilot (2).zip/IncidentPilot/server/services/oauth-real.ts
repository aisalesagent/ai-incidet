/**
 * Real OAuth Service - Production OAuth integrations
 */

export interface TokenExchange {
  accessToken: string;
  refreshToken?: string;
  expiresIn?: number;
  tokenType: string;
}

export class OAuthConfigError extends Error {
  constructor(provider: string) {
    super(`${provider} OAuth not configured. Missing credentials.`);
    this.name = "OAuthConfigError";
  }
}

export class RealOAuthService {
  static validateGitHubConfig(): void {
    if (!process.env.GITHUB_CLIENT_ID || !process.env.GITHUB_CLIENT_SECRET) {
      throw new OAuthConfigError("GitHub");
    }
  }

  static validateJiraConfig(): void {
    if (!process.env.JIRA_CLIENT_ID || !process.env.JIRA_CLIENT_SECRET) {
      throw new OAuthConfigError("Jira");
    }
  }

  static validateSlackConfig(): void {
    if (!process.env.SLACK_CLIENT_ID || !process.env.SLACK_CLIENT_SECRET) {
      throw new OAuthConfigError("Slack");
    }
  }

  static getRedirectUri(provider: string, requestHost?: string): string {
    let baseUrl: string;
    
    if (requestHost) {
      // Use the request host if provided (from Express req.get('host'))
      const protocol = requestHost.includes('localhost') ? 'http' : 'https';
      baseUrl = `${protocol}://${requestHost}`;
    } else {
      baseUrl = process.env.API_BASE_URL || process.env.REPLIT_URL || "http://localhost:5000";
    }
    
    return `${baseUrl}/api/oauth/${provider}/callback`;
  }

  static getGitHubAuthUrl(state: string, requestHost?: string): string {
    this.validateGitHubConfig();
    const params = new URLSearchParams({
      client_id: process.env.GITHUB_CLIENT_ID!,
      redirect_uri: this.getRedirectUri("github", requestHost),
      scope: "repo,read:org,user:email,admin:repo_hook",
      state,
      allow_signup: "true",
    });
    return `https://github.com/login/oauth/authorize?${params}`;
  }

  static async exchangeGitHubCode(code: string, requestHost?: string): Promise<TokenExchange> {
    this.validateGitHubConfig();
    const response = await fetch("https://github.com/login/oauth/access_token", {
      method: "POST",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        client_id: process.env.GITHUB_CLIENT_ID,
        client_secret: process.env.GITHUB_CLIENT_SECRET,
        code,
        redirect_uri: this.getRedirectUri("github", requestHost),
      }),
    });

    const data = await response.json() as any;
    if (data.error) {
      throw new Error(`GitHub OAuth error: ${data.error_description || data.error}`);
    }

    return {
      accessToken: data.access_token,
      tokenType: "bearer",
      expiresIn: 28800,
    };
  }

  static async getGitHubUser(accessToken: string): Promise<any> {
    const response = await fetch("https://api.github.com/user", {
      headers: {
        "Authorization": `token ${accessToken}`,
        "Accept": "application/vnd.github.v3+json",
      },
    });

    if (!response.ok) {
      throw new Error("Failed to fetch GitHub user");
    }

    return response.json();
  }

  static getJiraAuthUrl(state: string, requestHost?: string): string {
    this.validateJiraConfig();
    const params = new URLSearchParams({
      client_id: process.env.JIRA_CLIENT_ID!,
      redirect_uri: this.getRedirectUri("jira", requestHost),
      scope: "read:jira-work manage:jira-project write:jira-work read:me offline_access",
      state,
      response_type: "code",
      prompt: "consent",
    });
    return `https://auth.atlassian.com/authorize?${params}`;
  }

  static async exchangeJiraCode(code: string, requestHost?: string): Promise<TokenExchange> {
    this.validateJiraConfig();
    const response = await fetch("https://auth.atlassian.com/oauth/token", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        grant_type: "authorization_code",
        client_id: process.env.JIRA_CLIENT_ID,
        client_secret: process.env.JIRA_CLIENT_SECRET,
        code,
        redirect_uri: this.getRedirectUri("jira", requestHost),
      }),
    });

    const data = await response.json() as any;
    if (data.error) {
      throw new Error(`Jira OAuth error: ${data.error_description || data.error}`);
    }

    return {
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      tokenType: data.token_type,
      expiresIn: data.expires_in,
    };
  }

  static async getJiraUser(accessToken: string): Promise<any> {
    const response = await fetch("https://api.atlassian.com/me", {
      headers: { "Authorization": `Bearer ${accessToken}` },
    });

    if (!response.ok) {
      throw new Error("Failed to fetch Jira user");
    }

    return response.json();
  }

  static getSlackAuthUrl(state: string, requestHost?: string): string {
    this.validateSlackConfig();
    const params = new URLSearchParams({
      client_id: process.env.SLACK_CLIENT_ID!,
      redirect_uri: this.getRedirectUri("slack", requestHost),
      scope: "chat:write,incoming-webhook,channels:manage,users:read,chat:write.public,commands",
      state,
      user_scope: "chat:write",
    });
    return `https://slack.com/oauth/v2/authorize?${params}`;
  }

  static async exchangeSlackCode(code: string, requestHost?: string): Promise<TokenExchange> {
    this.validateSlackConfig();
    const response = await fetch("https://slack.com/api/oauth.v2.access", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: process.env.SLACK_CLIENT_ID!,
        client_secret: process.env.SLACK_CLIENT_SECRET!,
        code,
        redirect_uri: this.getRedirectUri("slack", requestHost),
      }).toString(),
    });

    const data = await response.json() as any;
    if (!data.ok) {
      throw new Error(`Slack OAuth error: ${data.error}`);
    }

    return { accessToken: data.access_token, tokenType: "bearer" };
  }

  static encryptCredentials(creds: any): string {
    return Buffer.from(JSON.stringify(creds)).toString("base64");
  }

  static decryptCredentials(encrypted: string): any {
    return JSON.parse(Buffer.from(encrypted, "base64").toString("utf-8"));
  }
}
