import type { Incident } from "@shared/schema";

export class JiraService {
  private baseUrl: string;
  private email: string;
  private apiToken: string;

  constructor(config?: { baseUrl?: string; email?: string; apiToken?: string }) {
    this.baseUrl = config?.baseUrl || process.env.JIRA_BASE_URL || "";
    this.email = config?.email || process.env.JIRA_EMAIL || "";
    this.apiToken = config?.apiToken || process.env.JIRA_API_TOKEN || "";
  }

  /**
   * Create a Jira ticket for an incident
   */
  async createTicket(
    incident: Incident,
    projectKey: string
  ): Promise<{ key: string; url: string }> {
    try {
      console.log(`Creating Jira ticket in project ${projectKey} for incident ${incident.id}`);

      // Mock implementation - in production, this would use Jira REST API
      const ticketKey = `${projectKey}-${Math.floor(Math.random() * 1000) + 1}`;
      const ticketUrl = `${this.baseUrl}/browse/${ticketKey}`;

      return {
        key: ticketKey,
        url: ticketUrl,
      };

      // Production implementation would look like:
      /*
      const auth = Buffer.from(`${this.email}:${this.apiToken}`).toString('base64');

      const response = await fetch(`${this.baseUrl}/rest/api/3/issue`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fields: {
            project: { key: projectKey },
            summary: incident.title,
            description: {
              type: 'doc',
              version: 1,
              content: [
                {
                  type: 'paragraph',
                  content: [
                    {
                      type: 'text',
                      text: incident.description || '',
                    },
                  ],
                },
              ],
            },
            issuetype: { name: 'Bug' },
            priority: this.mapSeverityToPriority(incident.severity),
            labels: ['incident', incident.severity],
          },
        }),
      });

      const data = await response.json();

      return {
        key: data.key,
        url: `${this.baseUrl}/browse/${data.key}`,
      };
      */
    } catch (error) {
      console.error("Error creating Jira ticket:", error);
      throw new Error("Failed to create Jira ticket");
    }
  }

  /**
   * Update Jira ticket when incident changes
   */
  async updateTicket(
    ticketKey: string,
    updates: { status?: string; severity?: string; description?: string }
  ): Promise<void> {
    try {
      console.log(`Updating Jira ticket ${ticketKey}`);

      // Mock implementation
      // Production would use Jira REST API to update the ticket
    } catch (error) {
      console.error("Error updating Jira ticket:", error);
      throw new Error("Failed to update Jira ticket");
    }
  }

  /**
   * Sync incident status to Jira
   */
  async syncStatus(ticketKey: string, status: string): Promise<void> {
    try {
      const jiraStatus = this.mapIncidentStatusToJira(status);
      console.log(`Syncing status for ${ticketKey} to ${jiraStatus}`);

      // Mock implementation
      // Production would transition the ticket through Jira workflows
    } catch (error) {
      console.error("Error syncing Jira status:", error);
      throw new Error("Failed to sync Jira status");
    }
  }

  /**
   * Link existing Jira ticket to incident
   */
  async linkTicket(ticketKey: string): Promise<{ valid: boolean; url: string }> {
    try {
      // Validate ticket key format
      if (!/^[A-Z]+-\d+$/.test(ticketKey)) {
        return { valid: false, url: "" };
      }

      return {
        valid: true,
        url: `${this.baseUrl}/browse/${ticketKey}`,
      };
    } catch (error) {
      console.error("Error linking Jira ticket:", error);
      return { valid: false, url: "" };
    }
  }

  private mapSeverityToPriority(severity: string): { name: string } {
    const priorityMap: Record<string, string> = {
      critical: "Highest",
      high: "High",
      medium: "Medium",
      low: "Low",
    };

    return { name: priorityMap[severity] || "Medium" };
  }

  private mapIncidentStatusToJira(status: string): string {
    const statusMap: Record<string, string> = {
      draft: "To Do",
      open: "In Progress",
      investigating: "In Progress",
      resolved: "Resolved",
      closed: "Done",
    };

    return statusMap[status] || "To Do";
  }
}

export const jiraService = new JiraService();
