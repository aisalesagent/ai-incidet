import { Queue, Worker, Job } from "bullmq";
import { Redis } from "ioredis";
import { storage } from "../storage";
import { aiService } from "../services/ai-service";

// Redis connection configuration
const connection = new Redis({
  host: process.env.REDIS_HOST || "localhost",
  port: parseInt(process.env.REDIS_PORT || "6379"),
  maxRetriesPerRequest: null,
});

// Create job queue
export const aiAnalysisQueue = new Queue("ai-analysis", { connection });

interface AIAnalysisJob {
  incidentId: string;
  organizationId: string;
  userId: string;
}

// Worker to process AI analysis jobs
const aiAnalysisWorker = new Worker<AIAnalysisJob>(
  "ai-analysis",
  async (job: Job<AIAnalysisJob>) => {
    const { incidentId, organizationId, userId } = job.data;

    try {
      console.log(`Processing AI analysis for incident ${incidentId}`);

      // Get incident data
      const incident = await storage.getIncident(incidentId);
      if (!incident) {
        throw new Error(`Incident ${incidentId} not found`);
      }

      // Update job progress
      await job.updateProgress(10);

      // Perform AI analysis
      const analysis = await aiService.analyzeIncident(incident);

      await job.updateProgress(80);

      // Update incident with AI analysis results
      await storage.updateIncident(incidentId, {
        aiAnalysis: analysis,
      });

      // Add activity log
      await storage.addIncidentActivity({
        incidentId,
        type: "ai_analysis",
        content: "AI analysis completed",
      });

      // Create notification for incident owner
      if (incident.assignedToId) {
        await storage.createNotification({
          userId: incident.assignedToId,
          organizationId,
          type: "incident_updated",
          title: "AI analysis completed",
          message: `AI analysis is ready for incident: ${incident.title}`,
          incidentId,
        });
      }

      await job.updateProgress(100);

      console.log(`AI analysis completed for incident ${incidentId}`);

      return { success: true, incidentId, analysis };
    } catch (error) {
      console.error(`Error processing AI analysis for incident ${incidentId}:`, error);
      throw error;
    }
  },
  {
    connection,
    concurrency: 5, // Process up to 5 jobs in parallel
  }
);

// Worker event listeners
aiAnalysisWorker.on("completed", (job) => {
  console.log(`Job ${job.id} completed successfully`);
});

aiAnalysisWorker.on("failed", (job, error) => {
  console.error(`Job ${job?.id} failed:`, error);
});

aiAnalysisWorker.on("error", (error) => {
  console.error("Worker error:", error);
});

// Export function to queue AI analysis
export async function queueAIAnalysis(
  incidentId: string,
  organizationId: string,
  userId: string
): Promise<Job<AIAnalysisJob>> {
  return await aiAnalysisQueue.add(
    "analyze-incident",
    {
      incidentId,
      organizationId,
      userId,
    },
    {
      attempts: 3,
      backoff: {
        type: "exponential",
        delay: 2000,
      },
    }
  );
}

// Health check function
export async function getQueueHealth() {
  const [waiting, active, completed, failed] = await Promise.all([
    aiAnalysisQueue.getWaitingCount(),
    aiAnalysisQueue.getActiveCount(),
    aiAnalysisQueue.getCompletedCount(),
    aiAnalysisQueue.getFailedCount(),
  ]);

  return {
    queue: "ai-analysis",
    waiting,
    active,
    completed,
    failed,
    healthy: active < 100 && failed < 10,
  };
}

console.log("✓ AI analysis queue and worker initialized");
