# AI Incident Management SaaS

## Overview

This is an intelligent incident management platform designed for DevOps and SRE teams to manage, track, and resolve production incidents. The application combines real-time incident tracking with AI-powered analysis to help teams quickly identify root causes, predict severity, and generate actionable insights during critical situations.

The platform emphasizes clarity under pressure with a clean, productivity-focused UI inspired by Linear, Notion, and monitoring tools like DataDog/PagerDuty. It supports multi-tenant organizations, team collaboration, and integrates with popular development tools.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Updates (Session: Nov 25, 2025)

### Completed Features
- ✅ **Authentication System**: Full login/signup flow with session-based auth
- ✅ **App Loading**: Fixed blank page issue with proper loading states
- ✅ **User Menu**: Implemented dropdown with Profile, Billing, Settings, Logout functions
- ✅ **Vite HMR**: Disabled problematic Hot Module Replacement to prevent WebSocket errors
- ✅ **Rate Limiting**: Configured Express proxy trust for development environment
- ✅ **API Integration**: Auth routes fully functional at `/api/auth/signup` and `/api/auth/login`
- ✅ **TypeScript Types**: Added missing CORS type definitions
- ✅ **Documentation**: Created comprehensive README.md with setup, usage, and deployment instructions
- ✅ **Self-Hosted Setup**: Configured for independent infrastructure deployment (no Replit dependencies)

### Current Status
- **Application**: Running smoothly on port 5000
- **Frontend**: React with TypeScript, Vite, Tailwind CSS, Shadcn/ui
- **Backend**: Express.js with full API routes and WebSocket support
- **Database**: PostgreSQL - configured for self-hosted or managed services
- **Auth Flow**: Session-based auth with token storage in sessionStorage
- **User Interface**: Professional UI with dark/light theme support
- **Deployment Ready**: Can deploy to Docker, VPS, Kubernetes, or any Node.js hosting

### Self-Hosted Infrastructure Support
- ✅ Docker containerization ready
- ✅ Environment variable configuration for custom infrastructure
- ✅ PostgreSQL connection pooling with Drizzle ORM
- ✅ Production build optimization via esbuild
- ✅ No Replit-specific dependencies in core functionality
- ✅ Vite config has conditional Replit plugins (won't load without REPL_ID)

### Known Limitations
- User authentication uses simplified token system (not full Clerk integration)
- Mock user data ("John Doe") - ready for real user data integration
- AI analysis endpoints awaiting Gemini API configuration

## System Architecture

### Frontend Architecture

**Framework & Tooling**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool for fast development and optimized production builds
- Wouter for lightweight client-side routing
- TanStack Query (React Query) for server state management and caching

**UI System**
- Shadcn/ui component library built on Radix UI primitives for accessible, customizable components
- Tailwind CSS with custom design tokens for consistent styling
- Custom design system following a "New York" style with system-based approach
- Inter font for UI, JetBrains Mono for technical/code content
- Dark/light theme support with system preference detection

**State Management Pattern**
- Server state managed via React Query with automatic caching and invalidation
- Authentication state handled through custom hooks (`useAuth`, `useCurrentOrganization`)
- Local UI state managed with React hooks
- Real-time updates via WebSocket connections for incident notifications

### Backend Architecture

**Server Framework**
- Express.js with TypeScript for type-safe API development
- Modular route organization separating concerns (incidents, organizations, integrations, OAuth)
- Custom middleware for authentication, rate limiting, and security

**Authentication & Authorization**
- Clerk integration for user authentication and session management
- Custom `requireAuth` middleware validates Bearer tokens
- Development token support for local testing without Clerk
- Role-based access control (owner, admin, member) at organization level

**API Design**
- RESTful API endpoints following resource-oriented patterns
- Consistent error handling with structured error responses
- Rate limiting (100 requests per 15 min general, 10 for AI analysis)
- CORS configured for cross-origin requests with credentials support

**Background Jobs & Queue System**
- BullMQ job queue for asynchronous AI analysis processing
- Redis-backed queue for reliability and job persistence
- Worker processes handle long-running AI analysis tasks
- Progress tracking and failure recovery for AI jobs

### Data Storage

**Database**
- PostgreSQL via Neon serverless database
- Drizzle ORM for type-safe database queries and schema management
- WebSocket-enabled connection pooling for real-time capabilities

**Schema Design**
Core tables include:
- `organizations` - Multi-tenant organization data with Stripe billing integration
- `users` - User profiles linked to Clerk authentication
- `organization_members` - Many-to-many relationship with role-based access
- `incidents` - Primary incident tracking with status, severity, metadata
- `incident_activities` - Activity timeline for incident updates
- `notifications` - User notification system
- `integrations` - OAuth token storage for third-party services
- `audit_logs` - Security and compliance audit trail

**Data Relationships**
- Organizations have many members and incidents
- Incidents belong to organizations and can be assigned to users
- Activities track all changes to incidents
- Integrations are scoped to organizations

### External Dependencies

**AI/ML Services**
- Google Gemini AI API for incident analysis features:
  - Severity prediction with confidence scoring
  - Root cause analysis (RCA) generation
  - Impact assessment
  - Suggested action plans
  - Automated postmortem report generation

**Authentication**
- Clerk (via `@clerk/clerk-sdk-node`) for user authentication and session management
- Token-based authentication with Bearer tokens
- Session verification and user profile management

**Payment Processing**
- Stripe for subscription billing and payment management
- Customer creation and subscription lifecycle handling
- Webhook support for payment events (planned)

**Third-Party Integrations (OAuth)**
All integrations use OAuth 2.0 authorization code flow:

- **GitHub** - Repository linking and automatic issue creation for incidents
- **Jira** - Bidirectional ticket synchronization
- **Slack** - Real-time incident notifications to channels

OAuth implementation:
- State parameter validation for CSRF protection
- Dynamic redirect URI based on deployment environment (localhost, Replit, custom domain)
- Token storage in database with refresh token support
- Secure credential management via environment variables

**Development Tools**
- Replit-specific plugins for development environment integration
- Vite plugins for error overlays and debugging
- TypeScript for full-stack type safety

**Database & Infrastructure**
- Neon PostgreSQL serverless database
- WebSocket support for real-time features
- Connection pooling via `@neondatabase/serverless`

**Monitoring & Observability**
- Custom logging middleware for request/response tracking
- Error tracking with detailed stack traces
- Rate limiting for API protection

### Security Considerations

**Request Security**
- Helmet.js for security headers (CSP disabled in development for Vite compatibility)
- CORS with explicit origin configuration
- Rate limiting to prevent abuse
- Input validation using Zod schemas

**Data Protection**
- Environment variables for sensitive credentials
- Secure OAuth token storage
- Session-based authentication
- Audit logging for compliance

**API Security**
- Bearer token authentication
- Development mode token bypass for testing
- Request body size limits
- Raw body preservation for webhook verification