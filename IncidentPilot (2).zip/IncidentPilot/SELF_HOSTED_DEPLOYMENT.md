# Self-Hosted Deployment Guide

This guide explains how to deploy the AI Incident Management application to your own infrastructure.

## Prerequisites

- Node.js 18 or higher
- PostgreSQL 12 or higher
- A VPS, Docker host, or Kubernetes cluster
- Domain name (optional, but recommended)
- SSL certificate (for HTTPS)

## Quick Start (5 Steps)

### Step 1: Prepare Your Infrastructure

**Option A: Linux VPS**
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install nodejs npm postgresql postgresql-contrib nginx

# Start PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

**Option B: Docker**
```bash
# Install Docker and Docker Compose
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
```

**Option C: Managed Services**
- PostgreSQL: AWS RDS, Azure Database, Google Cloud SQL, DigitalOcean Managed PostgreSQL
- Hosting: AWS EC2, DigitalOcean Droplets, Linode, Hetzner, etc.

### Step 2: Clone and Configure

```bash
# Clone the repository
git clone <your-repo-url>
cd incident-management

# Copy environment template
cp .env.example .env

# Edit with your infrastructure details
nano .env  # or vi, or your preferred editor
```

**Critical settings in `.env`:**
```env
DATABASE_URL=postgresql://user:password@your-db-host:5432/incident_db
GEMINI_API_KEY=your_gemini_key
SESSION_SECRET=your_random_secret
NODE_ENV=production
PORT=5000
```

### Step 3: Set Up Database

```bash
# Install dependencies
npm install

# Run database migrations
npm run db:push
```

This creates all required tables in your PostgreSQL instance.

### Step 4: Build Application

```bash
npm run build
```

This produces:
- `dist/public/` - Compiled frontend (React)
- `dist/index.js` - Backend server

### Step 5: Start Application

**Development (testing):**
```bash
npm run dev
```

**Production:**
```bash
npm start
```

App will be available at `http://localhost:5000`

---

## Deployment Methods

### Method 1: Traditional Linux Server with Nginx

1. **Set up Nginx as reverse proxy**

Create `/etc/nginx/sites-available/incident-manager`:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    # SSL certificates (use Let's Encrypt)
    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    # Performance
    client_max_body_size 20M;
    gzip on;
    gzip_types text/plain text/css application/json application/javascript;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

2. **Enable the site**

```bash
sudo ln -s /etc/nginx/sites-available/incident-manager /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

3. **Get SSL certificate (free with Let's Encrypt)**

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot certonly --nginx -d your-domain.com
```

4. **Set up process manager (PM2)**

```bash
# Install PM2
sudo npm install -g pm2

# Create ecosystem config
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'incident-manager',
    script: './dist/index.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss'
  }]
};
EOF

# Start the app
pm2 start ecosystem.config.js
pm2 save
pm2 startup

# Monitor
pm2 logs incident-manager
```

---

### Method 2: Docker Deployment

1. **Create Dockerfile** (already in root):

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY dist ./dist
COPY node_modules ./node_modules

ENV NODE_ENV=production
EXPOSE 5000

CMD ["npm", "start"]
```

2. **Create docker-compose.yml**

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      DATABASE_URL: postgresql://incident:secure_password@postgres:5432/incident_db
      GEMINI_API_KEY: ${GEMINI_API_KEY}
      SESSION_SECRET: ${SESSION_SECRET}
      NODE_ENV: production
    depends_on:
      - postgres
    restart: always

  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_USER: incident
      POSTGRES_PASSWORD: secure_password
      POSTGRES_DB: incident_db
    volumes:
      - postgres_data:/var/lib/postgresql/data
    restart: always

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./certs:/etc/nginx/certs:ro
    depends_on:
      - app
    restart: always

volumes:
  postgres_data:
```

3. **Deploy**

```bash
docker-compose build
docker-compose up -d

# Monitor logs
docker-compose logs -f app
```

---

### Method 3: Kubernetes

1. **Create deployment manifest** (`k8s/deployment.yaml`):

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: incident-manager
  namespace: default
spec:
  replicas: 3
  selector:
    matchLabels:
      app: incident-manager
  template:
    metadata:
      labels:
        app: incident-manager
    spec:
      containers:
      - name: app
        image: your-registry/incident-manager:latest
        ports:
        - containerPort: 5000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: database-url
        - name: GEMINI_API_KEY
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: gemini-api-key
        - name: SESSION_SECRET
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: session-secret
        - name: NODE_ENV
          value: "production"
        resources:
          requests:
            cpu: 250m
            memory: 512Mi
          limits:
            cpu: 500m
            memory: 1Gi
        livenessProbe:
          httpGet:
            path: /api/health
            port: 5000
          initialDelaySeconds: 30
          periodSeconds: 10
```

2. **Create service**:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: incident-manager
spec:
  type: LoadBalancer
  selector:
    app: incident-manager
  ports:
  - port: 80
    targetPort: 5000
```

3. **Deploy**:

```bash
kubectl create secret generic app-secrets \
  --from-literal=database-url=postgresql://... \
  --from-literal=gemini-api-key=... \
  --from-literal=session-secret=...

kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
```

---

### Method 4: Platform as a Service (PaaS)

Deployable on: Railway, Render, Fly.io, Heroku alternatives, etc.

**Railway example:**
1. Connect GitHub repo
2. Create PostgreSQL database in Railway
3. Set environment variables in dashboard
4. Deploy!

**Environment variables to set:**
```
DATABASE_URL=<from Railway PostgreSQL>
GEMINI_API_KEY=<your key>
SESSION_SECRET=<random secret>
NODE_ENV=production
```

---

## Post-Deployment

### 1. Verify Installation

```bash
# Test health endpoint
curl https://your-domain.com/api/health

# Test login endpoint
curl -X POST https://your-domain.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test"}'
```

### 2. Set Up Backups

**PostgreSQL automated backups:**
```bash
# Create backup script
cat > /home/ubuntu/backup-db.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/home/ubuntu/backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
pg_dump $DATABASE_URL > $BACKUP_DIR/incident_db_$TIMESTAMP.sql.gz
# Keep only last 7 days
find $BACKUP_DIR -name "incident_db_*.sql.gz" -mtime +7 -delete
EOF

chmod +x /home/ubuntu/backup-db.sh

# Schedule with cron (daily at 2 AM)
crontab -e
# Add: 0 2 * * * /home/ubuntu/backup-db.sh
```

### 3. Enable Monitoring

**Application logs:**
```bash
# With PM2
pm2 logs incident-manager

# With Docker
docker-compose logs -f app
```

**System monitoring:**
- CPU, Memory, Disk usage
- Network throughput
- Database connections

**Tools:** Datadog, New Relic, Prometheus, ELK Stack

### 4. SSL Certificate Renewal

If using Let's Encrypt:
```bash
# Auto-renewal (typically runs via cron)
sudo certbot renew --quiet

# Test renewal
sudo certbot renew --dry-run
```

---

## Troubleshooting

### App won't start

```bash
# Check logs
npm run dev  # Development mode shows full errors

# Check port availability
lsof -i :5000

# Check database connection
psql $DATABASE_URL -c "SELECT 1;"
```

### Database connection error

```bash
# Verify connection string format
postgresql://username:password@host:port/database

# Test connection
psql postgresql://user:password@host:port/database

# Check firewall
sudo ufw allow 5432/tcp  # For Linux VPS
```

### High CPU/Memory usage

1. Check application logs for errors
2. Increase server resources
3. Enable clustering (PM2 with multiple workers)
4. Optimize database queries

### SSL certificate issues

```bash
# Check certificate validity
sudo certbot certificates

# Manually renew if needed
sudo certbot renew --force-renewal

# Check Nginx SSL config
sudo nginx -t
```

---

## Performance Tuning

### Database Optimization

```sql
-- Add indexes for common queries
CREATE INDEX idx_incidents_org_id ON incidents(organization_id);
CREATE INDEX idx_incidents_status ON incidents(status);
CREATE INDEX idx_incidents_severity ON incidents(severity);

-- Connection pooling (already configured in Drizzle)
```

### Application Optimization

```javascript
// Enable response compression (in Express)
import compression from 'compression';
app.use(compression());

// Cache static assets
app.use(express.static('dist/public', {
  maxAge: '1d'
}));
```

### Nginx Optimization

```nginx
# In nginx.conf
gzip on;
gzip_types text/plain text/css application/json application/javascript;
gzip_min_length 1000;
gzip_proxied any;

# Connection keepalive
keepalive_timeout 65;
```

---

## Security Checklist

- [ ] Change default passwords
- [ ] Enable firewall (UFW, Security Groups)
- [ ] Use strong SESSION_SECRET
- [ ] Enable HTTPS with valid certificate
- [ ] Set up backups and test recovery
- [ ] Monitor for suspicious activity
- [ ] Keep dependencies updated
- [ ] Enable database encryption
- [ ] Restrict database access by IP
- [ ] Set up automatic updates

---

## Support & Resources

- **PostgreSQL**: https://www.postgresql.org/docs/
- **Node.js**: https://nodejs.org/docs/
- **Docker**: https://docs.docker.com/
- **Kubernetes**: https://kubernetes.io/docs/
- **PM2**: https://pm2.keymetrics.io/

---

Need help? Check the logs and README.md for API documentation.
